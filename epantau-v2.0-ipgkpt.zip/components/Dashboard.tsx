import React, { useMemo, useState } from 'react';
import { EvaluationRecord, MonitoringSchedule } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie, Legend
} from 'recharts';

const PIE_COLORS = [
  '#4f46e5', // indigo-600
  '#06b6d4', // cyan-500
  '#10b981', // emerald-500
  '#f59e0b', // amber-500
  '#ec4899', // pink-500
  '#8b5cf6', // violet-500
  '#f43f5e', // rose-500
  '#14b8a6', // teal-500
  '#3b82f6', // blue-500
  '#eab308', // yellow-500
  '#a855f7', // purple-500
  '#f97316', // orange-500
  '#0284c7', // sky-600
  '#16a34a', // green-600
  '#db2777', // pink-600
  '#ea580c', // orange-600
];
import { 
  MagnifyingGlassIcon, 
  PrinterIcon,
  EyeIcon,
  AcademicCapIcon,
  PresentationChartBarIcon,
  UsersIcon,
  BuildingOfficeIcon,
  SparklesIcon,
  XMarkIcon,
  InformationCircleIcon,
  ArrowDownTrayIcon,
  TrashIcon,
  ArrowPathIcon,
  ChartBarSquareIcon,
  PencilSquareIcon,
  CalendarDaysIcon,
  MapPinIcon,
  CloudArrowUpIcon,
  FolderOpenIcon,
  CalendarIcon,
  FunnelIcon,
  CheckBadgeIcon,
  ClockIcon,
  ArchiveBoxArrowDownIcon,
  HandThumbUpIcon,
  ExclamationCircleIcon,
  UserPlusIcon,
  ClipboardDocumentCheckIcon,
  ShieldCheckIcon,
  CheckCircleIcon,
  UserCircleIcon,
  LockClosedIcon,
  KeyIcon,
  ComputerDesktopIcon,
  DevicePhoneMobileIcon
} from '@heroicons/react/24/outline';
import { generatePDF, generateSummaryPDF, generateFullDepartmentPDF } from '../services/pdfService';
import { uploadToGoogleDrive } from '../services/googleDriveService';
import { EVALUATION_CRITERIA, DEPARTMENTS, LECTURERS } from '../constants';
import { UserGuideModal } from './UserGuideModal';

interface Props {
  records: EvaluationRecord[];
  schedules: MonitoringSchedule[];
  lecturers: { name: string; department: string }[];
  allLecturers: { name: string; department: string }[]; 
  userRole: 'admin' | 'user';
  username?: string;
  onDeleteRecord: (id: string) => void;
  onDeleteMultipleRecords?: (recordIds: string[]) => void;
  onDeleteLecturer: (name: string, department: string) => void;
  onDeleteMultipleLecturers?: (lecturers: { name: string; department: string }[]) => void;
  onDeleteSchedule: (id: string) => void;
  onDeleteMultipleSchedules?: (ids: string[]) => void;
  onEditRecord: (record: EvaluationRecord) => void;
  onAddSchedule: (schedule: MonitoringSchedule) => void;
  onUpdateSchedule: (schedule: MonitoringSchedule) => void;
  onAddLecturer: (lecturer: { name: string; department: string }) => void;
  onUpdateLecturer: (oldName: string, oldDept: string, updatedLecturer: { name: string; department: string }) => void;
  onRefresh?: () => void;
  onSync?: () => void;
  isSyncing?: boolean;
  syncError?: string | null;
  lastSync?: Date | null;
  userDept?: string;
  isRestrictedUser?: boolean;
  onStartEvaluation?: (preset?: { lecturerName?: string; department?: string; course?: string; code?: string; date?: string; evaluatorName?: string }) => void;
  recentlySavedId?: string | null;
  recentlySavedAction?: 'created' | 'updated' | null;
}

const DRIVE_FOLDER_URL = "https://drive.google.com/drive/folders/1I5-K1Yv3SnFMBzUQtQnPzR82AeHWJqNw?usp=sharing";

const formatDate = (dateStr: string) => {
  if (!dateStr || !dateStr.includes('-')) return dateStr;
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const [year, month, day] = parts;
  return `${day}.${month}.${year}`;
};

export const Dashboard: React.FC<Props> = ({ 
  records, 
  schedules,
  lecturers,
  allLecturers,
  userRole,
  username,
  userDept,
  recentlySavedId,
  recentlySavedAction,
  onDeleteRecord,
  onDeleteMultipleRecords,
  onDeleteLecturer,
  onDeleteMultipleLecturers,
  onDeleteSchedule,
  onDeleteMultipleSchedules,
  onEditRecord,
  onAddSchedule,
  onUpdateSchedule,
  onAddLecturer,
  onUpdateLecturer,
  onRefresh,
  onSync,
  isSyncing = false,
  syncError,
  lastSync,
  isRestrictedUser,
  onStartEvaluation
}) => {
  const isRestricted = false;
  const isAdminView = userRole === 'admin';
  const canEdit = true; // Semua pengguna boleh mengemaskini (update) rekod/jadual jika perlu
  const canDelete = true; // Semua pensyarah dan Ketua Jabatan boleh memadam rekod pemantauan yang telah diisi jika berlaku kesilapan

  const [searchTerm, setSearchTerm] = useState('');
  const [statusSearchTerm, setStatusSearchTerm] = useState('');
  const [analysisType, setAnalysisType] = useState<'lecturer' | 'department'>('department');
  const [deptMetric, setDeptMetric] = useState<'score' | 'count'>('score');
  
  // Dedicated access check for TP
  const isTPUser = username?.toLowerCase() === 'tp';
  const [isTPUnlocked, setIsTPUnlocked] = useState(isTPUser);
  const [showTPAuthModal, setShowTPAuthModal] = useState(false);
  const [tpPasswordInput, setTpPasswordInput] = useState('');
  const [tpAuthError, setTpAuthError] = useState('');

  const [mainTab, setMainTab] = useState<'analytics' | 'status' | 'schedule' | 'summary' | 'tp_kj'>(
    isTPUser ? 'tp_kj' : (isRestricted ? 'schedule' : 'status')
  );
  
  // Department scoping: Fixed for department users, selectable for Admin
  const isFixedDept = !!userDept && userDept !== 'SEMUA';
  const [selectedDepartment, setSelectedDepartment] = useState<string>(isFixedDept ? userDept : 'all');
  const activeDepartment = isFixedDept ? userDept : selectedDepartment;
  const isDeptView = activeDepartment !== 'all';
  const currentDept = activeDepartment;

  const effectiveTab = (isDeptView && (mainTab === 'analytics' || mainTab === 'summary')) ? 'status' : mainTab;

  const handleSelectTPTab = () => {
    if (isTPUser || isTPUnlocked) {
      setMainTab('tp_kj');
    } else {
      setShowTPAuthModal(true);
      setTpPasswordInput('');
      setTpAuthError('');
    }
  };

  const handleTPAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tpPasswordInput.trim() === 'tp' || tpPasswordInput.trim() === 'tp123') {
      setIsTPUnlocked(true);
      setShowTPAuthModal(false);
      setMainTab('tp_kj');
      setTpPasswordInput('');
      setTpAuthError('');
    } else {
      setTpAuthError('Kata laluan tidak tepat! Hanya TP sahaja yang boleh log in dengan password tp.');
    }
  };

  // Dedicated KJ Monitoring state for TP
  const [kjSearchTerm, setKjSearchTerm] = useState('');
  const [kjStatusFilter, setKjStatusFilter] = useState<'all' | 'monitored' | 'unmonitored'>('all');
  const [kjDeptFilter, setKjDeptFilter] = useState<string>('all');
  const [selectedKJKeys, setSelectedKJKeys] = useState<Set<string>>(new Set());

  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('all');
  const [scheduleDeptFilter, setScheduleDeptFilter] = useState<string>('all');
  const [recordsDeptFilter, setRecordsDeptFilter] = useState<string>('all');
  const [selectedLecturerHistory, setSelectedLecturerHistory] = useState<{ name: string; records: EvaluationRecord[] } | null>(null);
  const [analysisDeptFilter, setAnalysisDeptFilter] = useState<string>('all');
  const [onlyKJ, setOnlyKJ] = useState(false);
  const [monitoringStatusFilter, setMonitoringStatusFilter] = useState<'all' | 'monitored' | 'unmonitored'>('all');
  const [onlyKJRecords, setOnlyKJRecords] = useState(false);
  const [onlyKJSchedule, setOnlyKJSchedule] = useState(false);
  
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [showAIModal, setShowAIModal] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [showLecturerModal, setShowLecturerModal] = useState(false);
  const [isOtherDept, setIsOtherDept] = useState(false);
  const [editingLecturer, setEditingLecturer] = useState<{ name: string; department: string } | null>(null);
  const [lecturerFormData, setLecturerFormData] = useState({ name: '', department: '', isKJ: false });
  const [activeLecturer, setActiveLecturer] = useState('');
  
  const [selectedDeptDetails, setSelectedDeptDetails] = useState<string | null>(null);
  
  const [isSavingToDrive, setIsSavingToDrive] = useState<string | null>(null);
  const [isBulkSaving, setIsBulkSaving] = useState<string | null>(null);

  const [editingScheduleId, setEditingScheduleId] = useState<string | null>(null);
  const [schedForm, setSchedForm] = useState({
    lecturerName: '',
    date: new Date().toISOString().split('T')[0],
    time: '08:00',
    course: '',
    code: '',
    location: ''
  });

  // Checkbox selection state for lecturers (key: "name|department")
  const [selectedLecturerKeys, setSelectedLecturerKeys] = useState<Set<string>>(new Set());

  const toggleSelectLecturer = (key: string) => {
    setSelectedLecturerKeys(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const toggleSelectAllVisible = (items: { name: string; department: string }[]) => {
    const visibleKeys = items.map(item => `${item.name}|${item.department}`);
    const allVisibleSelected = visibleKeys.length > 0 && visibleKeys.every(k => selectedLecturerKeys.has(k));
    setSelectedLecturerKeys(prev => {
      const next = new Set(prev);
      if (allVisibleSelected) {
        visibleKeys.forEach(k => next.delete(k));
      } else {
        visibleKeys.forEach(k => next.add(k));
      }
      return next;
    });
  };

  const handleBatchDeleteLecturers = () => {
    if (selectedLecturerKeys.size === 0) return;
    const targets = Array.from(selectedLecturerKeys).map(k => {
      const [name, department] = k.split('|');
      return { name, department: department || '' };
    });
    if (onDeleteMultipleLecturers) {
      onDeleteMultipleLecturers(targets);
    } else {
      targets.forEach(t => onDeleteLecturer(t.name, t.department));
    }
    setSelectedLecturerKeys(new Set());
  };

  // Checkbox selection state for evaluation records (record ID)
  const [selectedRecordIds, setSelectedRecordIds] = useState<Set<string>>(new Set());

  const toggleSelectRecord = (id: string) => {
    setSelectedRecordIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAllRecords = (displayedRecords: EvaluationRecord[]) => {
    const visibleIds = displayedRecords.map(r => r.id);
    const allSelected = visibleIds.length > 0 && visibleIds.every(id => selectedRecordIds.has(id));
    setSelectedRecordIds(prev => {
      const next = new Set(prev);
      if (allSelected) {
        visibleIds.forEach(id => next.delete(id));
      } else {
        visibleIds.forEach(id => next.add(id));
      }
      return next;
    });
  };

  const handleBatchDeleteRecords = () => {
    if (selectedRecordIds.size === 0) return;
    const ids = Array.from(selectedRecordIds);
    if (onDeleteMultipleRecords) {
      onDeleteMultipleRecords(ids);
    } else {
      ids.forEach(id => onDeleteRecord(id));
    }
    setSelectedRecordIds(new Set());
  };

  const handleEditSelectedRecord = () => {
    if (selectedRecordIds.size === 0) return;
    const firstId = Array.from(selectedRecordIds)[0];
    const target = records.find(r => r.id === firstId);
    if (target) {
      onEditRecord(target);
      setSelectedRecordIds(new Set());
    }
  };

  // Checkbox selection state for schedules (schedule ID)
  const [scheduleSearchTerm, setScheduleSearchTerm] = useState('');
  const [selectedScheduleIds, setSelectedScheduleIds] = useState<Set<string>>(new Set());

  const toggleSelectSchedule = (id: string) => {
    setSelectedScheduleIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAllSchedules = (displayedSchedules: MonitoringSchedule[]) => {
    const visibleIds = displayedSchedules.map(s => s.id);
    const allSelected = visibleIds.length > 0 && visibleIds.every(id => selectedScheduleIds.has(id));
    setSelectedScheduleIds(prev => {
      const next = new Set(prev);
      if (allSelected) {
        visibleIds.forEach(id => next.delete(id));
      } else {
        visibleIds.forEach(id => next.add(id));
      }
      return next;
    });
  };

  const handleBatchDeleteSchedules = () => {
    if (selectedScheduleIds.size === 0) return;
    const ids = Array.from(selectedScheduleIds);
    if (onDeleteMultipleSchedules) {
      onDeleteMultipleSchedules(ids);
    } else {
      ids.forEach(id => onDeleteSchedule(id));
    }
    setSelectedScheduleIds(new Set());
  };

  const handleDeleteAllSchedules = (targetSchedules: MonitoringSchedule[]) => {
    if (!targetSchedules || targetSchedules.length === 0) return;
    const ids = targetSchedules.map(s => s.id);
    if (onDeleteMultipleSchedules) {
      onDeleteMultipleSchedules(ids);
    } else {
      ids.forEach(id => onDeleteSchedule(id));
    }
  };

  // Lecturers, Records, and Schedules strictly scoped when viewing a department
  const currentDeptLecturers = useMemo(() => {
    if (isDeptView) {
      const source = (allLecturers && allLecturers.length > 0) ? allLecturers : lecturers;
      return source.filter(l => l.department === currentDept);
    }
    return allLecturers;
  }, [allLecturers, lecturers, isDeptView, currentDept]);

  const currentDeptRecords = useMemo(() => {
    if (isDeptView) {
      return records.filter(r => r.department === currentDept);
    }
    return records;
  }, [records, isDeptView, currentDept]);

  const currentDeptSchedules = useMemo(() => {
    if (isDeptView) {
      return schedules.filter(s => s.department === currentDept);
    }
    return schedules;
  }, [schedules, isDeptView, currentDept]);

  const deptStats = useMemo(() => {
    if (!isDeptView) return null;
    const total = currentDeptLecturers.length;
    const monitored = currentDeptLecturers.filter(l => currentDeptRecords.some(r => r.lecturerName.toLowerCase() === l.name.toLowerCase()));
    const unmonitored = currentDeptLecturers.filter(l => !currentDeptRecords.some(r => r.lecturerName.toLowerCase() === l.name.toLowerCase()));
    const kj = currentDeptLecturers.find(l => l.name.includes('(KJ)'));
    const kjMonitored = kj ? currentDeptRecords.some(r => r.lecturerName.toLowerCase() === kj.name.toLowerCase()) : false;
    const percentage = total > 0 ? Math.round((monitored.length / total) * 100) : 0;
    
    return {
      total,
      monitoredCount: monitored.length,
      unmonitoredCount: unmonitored.length,
      percentage,
      kj,
      kjMonitored
    };
  }, [isDeptView, currentDeptLecturers, currentDeptRecords]);

  const filteredRecords = useMemo(() => {
    const baseList = isDeptView ? currentDeptRecords : records;
    const filterDept = isDeptView ? currentDept : recordsDeptFilter;
    const filtered = baseList.filter(r => 
      r.lecturerName.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (!onlyKJRecords || r.lecturerName.includes('(KJ)')) &&
      (filterDept === 'all' || r.department === filterDept)
    );
    return [...filtered].sort((a, b) => {
      if (recentlySavedId) {
        if (a.id === recentlySavedId) return -1;
        if (b.id === recentlySavedId) return 1;
      }
      return (b.timestamp || 0) - (a.timestamp || 0);
    });
  }, [records, currentDeptRecords, searchTerm, onlyKJRecords, recordsDeptFilter, isDeptView, currentDept, recentlySavedId]);

  const newLecturers = useMemo(() => {
    return allLecturers.filter(l => !LECTURERS.some(staticL => staticL.name.toLowerCase() === l.name.toLowerCase()));
  }, [allLecturers]);

  const allMonitoringStatus = useMemo(() => {
    const baseList = isDeptView ? currentDeptLecturers : lecturers;
    const filterDept = isDeptView ? currentDept : selectedDeptFilter;
    const recordsSource = isDeptView ? currentDeptRecords : records;

    return baseList
      .filter(l => filterDept === 'all' || l.department === filterDept)
      .filter(l => !onlyKJ || l.name.includes('(KJ)'))
      .map(lec => {
        const lecturerRecords = recordsSource.filter(r => 
          r.lecturerName.toLowerCase() === lec.name.toLowerCase() && 
          r.department === lec.department
        );
        const isMonitored = lecturerRecords.length > 0;
        
        let avgScore = 0;
        let latestRecord = null;
        if (isMonitored) {
          const sorted = [...lecturerRecords].sort((a, b) => b.timestamp - a.timestamp);
          latestRecord = sorted[0];
          const allScores = lecturerRecords.flatMap(r => Object.values(r.scores));
          avgScore = allScores.length > 0 ? allScores.reduce((a, b) => (a as number) + (b as number), 0) / allScores.length : 0;
        }

        return {
          name: lec.name,
          department: lec.department,
          isMonitored,
          isKJ: lec.name.includes('(KJ)'),
          count: lecturerRecords.length,
          avgScore: parseFloat(avgScore.toFixed(2)),
          latestDate: latestRecord ? latestRecord.date : null,
          latestRecord: latestRecord,
          allRecords: lecturerRecords.sort((a, b) => b.timestamp - a.timestamp)
        };
      });
  }, [records, lecturers, currentDeptLecturers, currentDeptRecords, selectedDeptFilter, onlyKJ, isDeptView, currentDept]);

  const monitoredLecturersCount = useMemo(() => allMonitoringStatus.filter(i => i.isMonitored).length, [allMonitoringStatus]);
  const unmonitoredLecturersCount = useMemo(() => allMonitoringStatus.filter(i => !i.isMonitored).length, [allMonitoringStatus]);

  const monitoringStatus = useMemo(() => {
    return allMonitoringStatus
      .filter(item => {
        if (monitoringStatusFilter === 'monitored') return item.isMonitored;
        if (monitoringStatusFilter === 'unmonitored') return !item.isMonitored;
        return true;
      })
      .filter(item => item.name.toLowerCase().includes(statusSearchTerm.toLowerCase()));
  }, [allMonitoringStatus, monitoringStatusFilter, statusSearchTerm]);

  const unmonitoredLecturersOverall = useMemo(() => {
    return allLecturers.filter(l => !records.some(r => 
      r.lecturerName.toLowerCase() === l.name.toLowerCase() && 
      r.department === l.department
    ));
  }, [allLecturers, records]);

  const kjMonitoringStats = useMemo(() => {
    const allKJs = allLecturers.filter(l => l.name.includes('(KJ)'));
    const totalKJs = allKJs.length;
    const monitoredKJs = allKJs.filter(kj => records.some(r => 
      r.lecturerName.toLowerCase() === kj.name.toLowerCase() && 
      r.department === kj.department
    ));
    const monitoredCount = monitoredKJs.length;
    const percentage = totalKJs > 0 ? Math.round((monitoredCount / totalKJs) * 100) : 0;
 
    return {
      total: totalKJs,
      monitored: monitoredCount,
      percentage,
      unmonitored: allKJs.filter(kj => !records.some(r => 
        r.lecturerName.toLowerCase() === kj.name.toLowerCase() && 
        r.department === kj.department
      ))
    };
  }, [records, allLecturers]);

  // Dedicated data for Timbalan Pengarah (TP) monitoring Ketua Jabatan
  const kjFullList = useMemo(() => {
    const allKJs = allLecturers.filter(l => l.name.includes('(KJ)'));
    return allKJs.map(kj => {
      const kjRecords = records.filter(r => 
        r.lecturerName.toLowerCase() === kj.name.toLowerCase()
      ).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      
      const isMonitored = kjRecords.length > 0;
      const latestRecord = isMonitored ? kjRecords[0] : null;
      
      let avgScore = 0;
      if (isMonitored) {
        const allScores = kjRecords.flatMap(r => Object.values(r.scores || {}));
        avgScore = allScores.length > 0 ? allScores.reduce((a, b) => a + b, 0) / allScores.length : 0;
      }
      
      const hasLecturerSig = !!latestRecord?.lecturerSignature;
      const hasEvaluatorSig = !!latestRecord?.evaluatorSignature;
      const bothSigned = hasLecturerSig && hasEvaluatorSig;
      
      const kjSchedule = schedules.find(s => 
        s.lecturerName.toLowerCase() === kj.name.toLowerCase()
      );
      
      return {
        name: kj.name,
        department: kj.department,
        isMonitored,
        recordsCount: kjRecords.length,
        avgScore: parseFloat(avgScore.toFixed(2)),
        latestRecord,
        allRecords: kjRecords,
        hasLecturerSig,
        hasEvaluatorSig,
        bothSigned,
        schedule: kjSchedule
      };
    });
  }, [allLecturers, records, schedules]);

  const filteredKJList = useMemo(() => {
    return kjFullList.filter(kj => {
      const matchesSearch = kj.name.toLowerCase().includes(kjSearchTerm.toLowerCase()) ||
                            kj.department.toLowerCase().includes(kjSearchTerm.toLowerCase());
      const matchesStatus = kjStatusFilter === 'all' || 
                            (kjStatusFilter === 'monitored' && kj.isMonitored) ||
                            (kjStatusFilter === 'unmonitored' && !kj.isMonitored);
      const matchesDept = kjDeptFilter === 'all' || kj.department === kjDeptFilter;
      return matchesSearch && matchesStatus && matchesDept;
    });
  }, [kjFullList, kjSearchTerm, kjStatusFilter, kjDeptFilter]);

  const kjExecutiveKPIs = useMemo(() => {
    const total = kjFullList.length;
    const monitored = kjFullList.filter(k => k.isMonitored).length;
    const unmonitored = total - monitored;
    const percentage = total > 0 ? Math.round((monitored / total) * 100) : 0;
    const monitoredKJsWithScore = kjFullList.filter(k => k.isMonitored && k.avgScore > 0);
    const overallAvgScore = monitoredKJsWithScore.length > 0 
      ? (monitoredKJsWithScore.reduce((acc, k) => acc + k.avgScore, 0) / monitoredKJsWithScore.length).toFixed(2)
      : '0.00';
    const bothSignedCount = kjFullList.filter(k => k.bothSigned).length;
    return {
      total,
      monitored,
      unmonitored,
      percentage,
      overallAvgScore,
      bothSignedCount
    };
  }, [kjFullList]);

  const toggleSelectKJ = (key: string) => {
    setSelectedKJKeys(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const toggleSelectAllVisibleKJs = (items: { name: string; department: string }[]) => {
    const visibleKeys = items.map(item => `${item.name}|${item.department}`);
    const allVisibleSelected = visibleKeys.length > 0 && visibleKeys.every(k => selectedKJKeys.has(k));
    setSelectedKJKeys(prev => {
      const next = new Set(prev);
      if (allVisibleSelected) {
        visibleKeys.forEach(k => next.delete(k));
      } else {
        visibleKeys.forEach(k => next.add(k));
      }
      return next;
    });
  };

  const handleBatchDeleteKJRecords = () => {
    if (selectedKJKeys.size === 0) return;
    const targetKJNames = Array.from(selectedKJKeys).map(k => k.split('|')[0].toLowerCase());
    const recordsToDelete = records.filter(r => targetKJNames.includes(r.lecturerName.toLowerCase()));
    if (recordsToDelete.length === 0) {
      alert("Tiada rekod pemantauan bagi Ketua Jabatan yang dipilih untuk dipadam.");
      return;
    }
    if (confirm(`Adakah anda pasti untuk memadam ${recordsToDelete.length} rekod pemantauan bagi Ketua Jabatan yang dipilih?`)) {
      const ids = recordsToDelete.map(r => r.id);
      if (onDeleteMultipleRecords) {
        onDeleteMultipleRecords(ids);
      } else {
        ids.forEach(id => onDeleteRecord(id));
      }
      setSelectedKJKeys(new Set());
    }
  };

  // Aggregated item analysis for admins
  const itemAnalysis = useMemo(() => {
    const filteredRecordsForAnalysis = records.filter(r => 
      analysisDeptFilter === 'all' || r.department === analysisDeptFilter
    );
    
    if (filteredRecordsForAnalysis.length === 0) return [];
    
    const stats: Record<string, { total: number; count: number }> = {};
    filteredRecordsForAnalysis.forEach(r => {
      Object.entries(r.scores).forEach(([id, score]) => {
        if (!stats[id]) stats[id] = { total: 0, count: 0 };
        stats[id].total += score;
        stats[id].count += 1;
      });
    });

    return EVALUATION_CRITERIA.map(c => ({
      id: c.id,
      text: c.text,
      category: c.category,
      avg: parseFloat((stats[c.id]?.total / stats[c.id]?.count || 0).toFixed(2))
    })).sort((a, b) => a.avg - b.avg);
  }, [records, analysisDeptFilter]);

  const strengthsAndWeaknesses = useMemo(() => {
    const sorted = [...itemAnalysis].sort((a, b) => b.avg - a.avg);
    return {
      strengths: sorted.slice(0, 3),
      weaknesses: sorted.reverse().slice(0, 3)
    };
  }, [itemAnalysis]);

  const filteredSchedules = useMemo(() => {
    const baseList = isDeptView ? currentDeptSchedules : schedules;
    const filterDept = isDeptView ? currentDept : scheduleDeptFilter;
    return baseList
      .filter(s => filterDept === 'all' || s.department === filterDept)
      .filter(s => !onlyKJSchedule || s.lecturerName.includes('(KJ)'))
      .filter(s => {
        if (!scheduleSearchTerm) return true;
        const q = scheduleSearchTerm.toLowerCase();
        return (
          s.lecturerName.toLowerCase().includes(q) ||
          s.course.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q) ||
          (s.location && s.location.toLowerCase().includes(q)) ||
          s.department.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [schedules, currentDeptSchedules, scheduleDeptFilter, onlyKJSchedule, scheduleSearchTerm, isDeptView, currentDept]);

  const upcomingSchedules = useMemo(() => {
    const baseList = isDeptView ? currentDeptSchedules : schedules;
    return baseList
      .filter(s => s.status === 'Pending')
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 5);
  }, [schedules, currentDeptSchedules, isDeptView]);

  const activeDepartments = useMemo(() => {
    const fromLecturers = allLecturers.map(l => l.department);
    const combined = Array.from(new Set([...DEPARTMENTS, ...fromLecturers]));
    return combined.filter(Boolean).sort();
  }, [allLecturers]);

  const departmentMonitoringStats = useMemo(() => {
    return activeDepartments.map(dept => {
      const lecturersInDept = allLecturers.filter(l => l.department === dept);
      const totalInDept = lecturersInDept.length;
      const monitoredLecturers = lecturersInDept.filter(l => records.some(r => 
        r.lecturerName.toLowerCase() === l.name.toLowerCase() && 
        r.department === l.department
      ));
      const unmonitoredLecturers = lecturersInDept.filter(l => !records.some(r => 
        r.lecturerName.toLowerCase() === l.name.toLowerCase() && 
        r.department === l.department
      ));
      
      const newMonitoredInDept = monitoredLecturers.filter(l => 
        !LECTURERS.some(staticL => staticL.name.toLowerCase() === l.name.toLowerCase())
      );

      const monitoredCount = monitoredLecturers.length;
      const percentage = totalInDept > 0 ? Math.round((monitoredCount / totalInDept) * 100) : 0;
 
      const deptKJs = lecturersInDept.filter(l => l.name.includes('(KJ)'));
      const kjMonitored = deptKJs.length > 0 && deptKJs.every(kj => records.some(r => 
        r.lecturerName.toLowerCase() === kj.name.toLowerCase() && 
        r.department === kj.department
      ));

      return {
        name: dept,
        total: totalInDept,
        monitored: monitoredCount,
        percentage,
        kjMonitored,
        unmonitoredNames: unmonitoredLecturers.map(l => l.name),
        newMonitoredNames: newMonitoredInDept.map(l => l.name)
      };
    }).sort((a, b) => b.percentage - a.percentage);
  }, [records, allLecturers, activeDepartments]);

  const lecturerStats = useMemo(() => {
    const stats: Record<string, { total: number; count: number; name: string; department: string }> = {};
    records.forEach(r => {
      const scores = Object.values(r.scores) as number[];
      const avg = scores.length > 0 ? (scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
      const key = `${r.lecturerName}|${r.department}`;
      if (!stats[key]) stats[key] = { total: 0, count: 0, name: r.lecturerName, department: r.department };
      stats[key].total += avg;
      stats[key].count += 1;
    });

    return Object.entries(stats).map(([key, data]) => ({
      name: data.name,
      department: data.department,
      displayName: `${data.name} (${data.department})`,
      value: parseFloat((data.total / data.count).toFixed(2)),
      count: data.count
    })).sort((a, b) => b.value - a.value);
  }, [records]);

  const departmentStats = useMemo(() => {
    const stats: Record<string, { total: number; count: number; lecturers: Set<string>; evalCount: number }> = {};
    records.forEach(r => {
      const scores = Object.values(r.scores) as number[];
      const avg = scores.length > 0 ? (scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
      if (!stats[r.department]) stats[r.department] = { total: 0, count: 0, lecturers: new Set(), evalCount: 0 };
      stats[r.department].total += avg;
      stats[r.department].count += 1;
      stats[r.department].evalCount += 1;
      stats[r.department].lecturers.add(r.lecturerName);
    });

    return Object.entries(stats).map(([name, data]) => ({
      name,
      score: parseFloat((data.total / data.count).toFixed(2)),
      lecturerCount: data.lecturers.size,
      evalCount: data.evalCount
    })).sort((a, b) => deptMetric === 'score' ? b.score - a.score : b.lecturerCount - a.lecturerCount);
  }, [records, deptMetric]);

  const handleSaveToDrive = async (record: EvaluationRecord) => {
    setIsSavingToDrive(record.id);
    try {
      const pdfBlob = generatePDF(record, 'blob');
      const success = await uploadToGoogleDrive(record, pdfBlob);
      if (success) {
        alert(`Berjaya Disimpan ke Google Drive Admin!\n\nFolder Utama: iPantau_v2_Archive\nSub-folder Jabatan: ${record.department}\nFail: [${record.department}]_LAM-PT-03-04_${record.lecturerName.replace(/\s+/g, '_')}_${record.date}.pdf\n\nKlik OK untuk membuka folder digital.`);
        window.open(DRIVE_FOLDER_URL, "_blank");
      }
    } catch (error) {
      console.error(error);
      alert('Ralat semasa menyimpan ke Google Drive.');
    } finally {
      setIsSavingToDrive(null);
    }
  };

  const handleBulkExportToDrive = async (deptName: string) => {
    const deptRecords = records.filter(r => r.department === deptName);
    if (deptRecords.length === 0) {
      alert(`Tiada rekod lengkap ditemui untuk ${deptName}.`);
      return;
    }
    setIsBulkSaving(deptName);
    try {
      for (const record of deptRecords) {
        const pdfBlob = generatePDF(record, 'blob');
        await uploadToGoogleDrive(record, pdfBlob);
      }
      alert(`Berjaya Mengeksport ${deptRecords.length} rekod PDF pensyarah ${deptName}!\n\nSemua fail PDF telah disimpan ke dalam sub-folder [${deptName}] dalam Google Drive Admin.\n\nKlik OK untuk menyemak arkib.`);
      window.open(DRIVE_FOLDER_URL, "_blank");
    } catch (error) {
      console.error(error);
      alert('Ralat semasa mengeksport fail PDF ke Google Drive.');
    } finally {
      setIsBulkSaving(null);
    }
  };

  const exportToCSV = () => {
    if (records.length === 0) return;
    const headers = ["ID", "Tarikh", "Pensyarah", "Jabatan", "Kursus", "Kod", "Skor Purata"];
    const rows = records.map(r => {
      const scores = Object.values(r.scores) as number[];
      const avg = scores.length > 0 ? (scores.reduce((a, b) => (a as number) + (b as number), 0) / scores.length).toFixed(2) : "0";
      return [r.id, r.date, `"${r.lecturerName}"`, `"${r.department}"`, `"${r.course}"`, r.code, avg].join(",");
    });
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows].join("\n");
    const link = document.createElement("a");
    link.setAttribute("href", encodeURI(csvContent));
    link.setAttribute("download", `rekod_ipgkpt_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const generateAISummary = async (target: EvaluationRecord | string | { name: string; department: string }) => {
    setIsSummarizing(true);
    setAiSummary(null);
    setShowAIModal(true);
    
    let lecturerName = '';
    let recordsToAnalyze: EvaluationRecord[] = [];
    
    if (typeof target === 'string') {
      lecturerName = target;
      recordsToAnalyze = records.filter(r => r.lecturerName === target);
    } else if ('name' in target && 'department' in target) {
      lecturerName = target.name;
      recordsToAnalyze = records.filter(r => r.lecturerName === target.name && r.department === target.department);
    } else {
      const record = target as EvaluationRecord;
      lecturerName = record.lecturerName;
      recordsToAnalyze = [record];
    }
    
    setActiveLecturer(lecturerName);
    
    if (recordsToAnalyze.length === 0) {
      setAiSummary("Tiada rekod penilaian ditemui untuk pensyarah ini.");
      setIsSummarizing(false);
      return;
    }

    try {
      const dataString = recordsToAnalyze.map((r, idx) => {
        const scores = Object.entries(r.scores).map(([id, score]) => {
          const criterion = EVALUATION_CRITERIA.find(c => c.id === id);
          return `- ${criterion?.text}: ${score}/5`;
        }).join('\n');
        return `Penilaian ${idx + 1} (${r.date}):\nKursus: ${r.course}\nSkor:\n${scores}\nUlasan Pemantau: ${r.remarks || 'Tiada'}`;
      }).join('\n\n---\n\n');

      const prompt = `Anda adalah pakar penilai akademik. Berikan rumusan RINGKAS dan PADAT (Executive Summary) dalam Bahasa Melayu berdasarkan hasil penilaian pemantau berikut. 
      
      Fokus kepada:
      1. Tahap prestasi keseluruhan (Cemerlang/Baik/Memuaskan/Perlu Penambahbaikan).
      2. 2-3 kekuatan utama.
      3. 2-3 cadangan penambahbaikan yang spesifik.
      
      Gunakan format poin yang kemas.
      
      DATA PENILAIAN UNTUK ${lecturerName.toUpperCase()}:
      ${dataString}`;

      const res = await fetch("/api/gemini/summary", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP error! status: ${res.status}`);
      }

      const result = await res.json();
      setAiSummary(result.text || "Rumusan gagal dijana.");
    } catch (error: any) {
      console.error(error);
      setAiSummary(error.message || "Ralat menjana rumusan AI. Sila pastikan GEMINI_API_KEY telah dikonfigurasikan.");
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleNewLecturer = () => {
    setEditingLecturer(null);
    setLecturerFormData({ 
      name: '', 
      department: isDeptView ? currentDept : (isAdminView ? '' : (userDept || '')), 
      isKJ: false 
    });
    setIsOtherDept(false);
    setShowLecturerModal(true);
  };

  const handleEditLecturer = (lec: { name: string; department: string }) => {
    setEditingLecturer(lec);
    const isKJ = lec.name.includes('(KJ)');
    const cleanName = lec.name.replace(' (KJ)', '').replace('(KJ)', '').trim();
    setLecturerFormData({ name: cleanName, department: lec.department, isKJ });
    setIsOtherDept(!DEPARTMENTS.includes(lec.department));
    setShowLecturerModal(true);
  };

  const handleLecturerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = lecturerFormData.isKJ 
      ? `${lecturerFormData.name.trim()} (KJ)` 
      : lecturerFormData.name.trim();
    
    const submissionData = {
      name: finalName,
      department: isDeptView ? currentDept : lecturerFormData.department
    };

    if (editingLecturer) {
      onUpdateLecturer(editingLecturer.name, editingLecturer.department, submissionData);
    } else {
      onAddLecturer(submissionData);
    }
    setShowLecturerModal(false);
  };

  const handleEditSchedule = (s: MonitoringSchedule) => {
    setEditingScheduleId(s.id);
    setSchedForm({
      lecturerName: s.lecturerName,
      date: s.date,
      time: s.time,
      course: s.course,
      code: s.code,
      location: s.location
    });
    setShowScheduleModal(true);
  };

  const handleNewSchedule = (lecturerName?: string) => {
    setEditingScheduleId(null);
    setSchedForm({
      lecturerName: lecturerName || '',
      date: new Date().toISOString().split('T')[0],
      time: '08:00',
      course: '',
      code: '',
      location: ''
    });
    setShowScheduleModal(true);
  };

  const handleScheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const candidateList = isDeptView ? currentDeptLecturers : allLecturers;
    const lecturer = candidateList.find(l => l.name === schedForm.lecturerName) || allLecturers.find(l => l.name === schedForm.lecturerName) || lecturers.find(l => l.name === schedForm.lecturerName);
    if (!lecturer) return;
    const deptToAssign = isDeptView ? currentDept : lecturer.department;
    if (editingScheduleId) {
      const existing = schedules.find(s => s.id === editingScheduleId);
      const updated: MonitoringSchedule = {
        ...schedForm,
        id: editingScheduleId,
        department: deptToAssign,
        timestamp: existing?.timestamp || Date.now(),
        status: existing?.status || 'Pending'
      };
      onUpdateSchedule(updated);
    } else {
      const newSched: MonitoringSchedule = {
        ...schedForm,
        id: Math.random().toString(36).substr(2, 9),
        department: deptToAssign,
        timestamp: Date.now(),
        status: 'Pending'
      };
      onAddSchedule(newSched);
    }
    setShowScheduleModal(false);
  };

  const overallMean = useMemo(() => {
    if (lecturerStats.length === 0) return "0.00";
    return (lecturerStats.reduce((a, b) => a + b.value, 0) / lecturerStats.length).toFixed(2);
  }, [lecturerStats]);

  const overallMonitoredPercentage = useMemo(() => {
    if (allLecturers.length === 0) return "0%";
    const monitoredCount = allLecturers.length - unmonitoredLecturersOverall.length;
    const pct = (monitoredCount / allLecturers.length) * 100;
    return (pct % 1 === 0 ? pct.toFixed(0) : pct.toFixed(1)) + "%";
  }, [allLecturers, unmonitoredLecturersOverall]);

  const activeChartData = useMemo(() => {
    if (analysisType === 'lecturer') {
      return lecturerStats.map(d => ({ name: d.displayName, value: d.value }));
    } else {
      return departmentStats.map(d => ({ name: d.name, value: deptMetric === 'score' ? d.score : d.lecturerCount }));
    }
  }, [analysisType, lecturerStats, departmentStats, deptMetric]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">PINTAR-Dash</h2>
          <div className="flex flex-wrap items-center gap-2 mt-1">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">
              {isDeptView ? `Paparan Jabatan: ${currentDept}` : 'Status PINTAR-Dash'}
            </p>
            <span className="text-slate-300">•</span>
            <button 
              type="button"
              onClick={() => setShowSyncModal(true)}
              className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200/60 px-2 py-0.5 rounded-lg transition-colors cursor-pointer group"
              title="Klik untuk melihat status penyelarasan merentasi semua peranti (Laptop, Android, Mac & Windows)"
            >
              <span className={`w-2 h-2 rounded-full ${syncError ? 'bg-rose-500 animate-pulse' : 'bg-emerald-500 animate-pulse'}`} />
              <span>Selaras: Laptop, Android, Mac & Windows</span>
              {lastSync && (
                <span className="text-emerald-600/80 text-[9px] font-medium">
                  ({lastSync.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                </span>
              )}
              <InformationCircleIcon className="h-3 w-3 text-emerald-500 ml-0.5 opacity-60 group-hover:opacity-100" />
            </button>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {onSync && (
            <button 
              type="button"
              onClick={onSync} 
              disabled={isSyncing}
              className="flex items-center gap-2 px-3.5 sm:px-4 py-2 bg-gradient-to-r from-indigo-50 to-blue-50 hover:from-indigo-100 hover:to-blue-100 active:bg-indigo-200 text-indigo-700 border border-indigo-200 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-sm active:scale-95 disabled:opacity-60 min-h-[40px] cursor-pointer"
              title="Segerak data sekarang untuk selaraskan rekod ke Laptop, Telefon Pintar (Android/iOS) dan Komputer (Mac/Windows)"
            >
              <ArrowPathIcon className={`h-4 w-4 text-indigo-600 shrink-0 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Menyelaraskan...' : 'Segerak Semua Peranti'}</span>
              <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 bg-white text-[9px] text-indigo-600 font-bold rounded border border-indigo-100 shadow-2xs">
                <ComputerDesktopIcon className="h-3 w-3 inline text-slate-500" />
                <DevicePhoneMobileIcon className="h-3 w-3 inline text-slate-500" />
                Semua OS
              </span>
            </button>
          )}
          {isAdminView && (
            <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-3 py-1.5 shadow-sm">
              <BuildingOfficeIcon className="h-4 w-4 text-indigo-600" />
              <span className="text-[11px] font-bold text-slate-500">Paparan:</span>
              <select 
                value={selectedDepartment}
                onChange={e => {
                  setSelectedDepartment(e.target.value);
                  if (e.target.value !== 'all') {
                    setMainTab('status');
                  }
                }}
                className="bg-transparent text-xs font-black text-indigo-700 outline-none cursor-pointer"
              >
                <option value="all">Semua Jabatan (Seluruh Kampus)</option>
                {activeDepartments.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
          )}
          {isFixedDept && (
            <div className="flex items-center gap-1.5 bg-indigo-50 border border-indigo-200 rounded-xl px-3 py-1.5">
              <BuildingOfficeIcon className="h-4 w-4 text-indigo-600" />
              <span className="text-xs font-black text-indigo-800">{userDept}</span>
              <span className="text-[9px] font-bold text-indigo-500 bg-white px-1.5 py-0.5 rounded border border-indigo-100 uppercase">Jabatan Sahaja</span>
            </div>
          )}
          <button onClick={() => setShowGuideModal(true)} className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-all shadow-sm">
            <InformationCircleIcon className="h-4 w-4 text-indigo-600" /> Panduan
          </button>
          {!isRestricted && onStartEvaluation && (
            <button 
              onClick={() => onStartEvaluation({ department: isDeptView ? currentDept : undefined })} 
              className="flex items-center gap-2 px-4 py-2 bg-rose-600 rounded-xl text-sm font-bold text-white hover:bg-rose-700 transition-all shadow-lg shadow-rose-200 active:scale-95"
              title="Mula sesi penilaian untuk pensyarah"
            >
              <ClipboardDocumentCheckIcon className="h-4 w-4" /> Nilai Pensyarah {isDeptView ? `(${currentDept})` : ''}
            </button>
          )}
          <button onClick={() => handleNewSchedule()} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 rounded-xl text-sm font-bold text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
            <CalendarIcon className="h-4 w-4" /> Daftar Jadual {isDeptView ? `(${currentDept})` : ''}
          </button>
          
          {!isRestricted && (
            <>
              <button onClick={() => generateFullDepartmentPDF(isDeptView ? currentDeptRecords : records, 'view')} className="flex items-center gap-2 px-4 py-2 bg-purple-50 border border-purple-200 rounded-xl text-sm font-bold text-purple-700 hover:bg-purple-100 transition-all shadow-sm">
                <EyeIcon className="h-4 w-4" /> Lihat Rekod
              </button>
              <button onClick={() => generateSummaryPDF(lecturerStats, departmentStats, overallMean, (isDeptView ? currentDeptRecords : records).length, 'save')} className="flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-xl text-sm font-bold text-white hover:bg-slate-900 transition-all shadow-lg shadow-slate-200">
                <PrinterIcon className="h-4 w-4" /> Cetak Ringkasan
              </button>
              <button onClick={exportToCSV} className="flex items-center gap-2 px-4 py-2 bg-amber-50 border border-amber-200 rounded-xl text-sm font-bold text-amber-700 hover:bg-amber-100 transition-all shadow-sm">
                <ArrowDownTrayIcon className="h-4 w-4" /> Eksport CSV
              </button>
              {userRole === 'admin' && (
                <a href={DRIVE_FOLDER_URL} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-4 py-2 bg-slate-100 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 hover:bg-slate-200 transition-all shadow-sm">
                  <FolderOpenIcon className="h-4 w-4 text-emerald-600" /> Folder Admin
                </a>
              )}
            </>
          )}
        </div>
      </div>

      <div className="flex border-b border-slate-200 gap-8 overflow-x-auto whitespace-nowrap pb-1">
        {isDeptView ? (
          <>
            {!isRestricted && (
              <button onClick={() => setMainTab('status')} className={`pb-4 text-sm font-bold transition-all relative ${effectiveTab === 'status' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>
                Status Penilaian ({currentDept})
                {effectiveTab === 'status' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
              </button>
            )}
            <button onClick={() => setMainTab('schedule')} className={`pb-4 text-sm font-bold transition-all relative ${effectiveTab === 'schedule' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>
              Pendaftaran Jadual ({currentDept})
              {effectiveTab === 'schedule' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
            </button>
            <button 
              onClick={handleSelectTPTab} 
              className={`pb-4 text-sm font-bold transition-all relative flex items-center gap-1.5 ${effectiveTab === 'tp_kj' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <ShieldCheckIcon className="h-4 w-4 text-purple-600" />
              <span>Pemantauan KJ (TP)</span>
              {!(isTPUser || isTPUnlocked) ? (
                <LockClosedIcon className="h-3.5 w-3.5 text-slate-400" title="Perlu kata laluan TP" />
              ) : (
                <span className="w-2 h-2 rounded-full bg-emerald-500" title="Sesi TP disahkan" />
              )}
              {effectiveTab === 'tp_kj' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
            </button>
          </>
        ) : (
          <>
            {!isRestricted && (
              <>
                <button onClick={() => setMainTab('analytics')} className={`pb-4 text-sm font-bold transition-all relative ${mainTab === 'analytics' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>
                  Rekod & Analisis
                  {mainTab === 'analytics' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
                </button>
                <button onClick={() => setMainTab('status')} className={`pb-4 text-sm font-bold transition-all relative ${mainTab === 'status' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>
                  Status Pemantauan
                  {mainTab === 'status' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
                </button>
              </>
            )}
            <button 
              onClick={handleSelectTPTab} 
              className={`pb-4 text-sm font-bold transition-all relative flex items-center gap-2 ${mainTab === 'tp_kj' ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <ShieldCheckIcon className="h-4 w-4 text-purple-600" />
              <span>Pemantauan Ketua Jabatan (TP)</span>
              {!(isTPUser || isTPUnlocked) ? (
                <span className="flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                  <LockClosedIcon className="h-3 w-3 text-slate-500" /> Kunci TP
                </span>
              ) : (
                <span className="px-2 py-0.5 text-[10px] font-black rounded-full bg-purple-100 text-purple-700 border border-purple-200">
                  Khas TP ✓
                </span>
              )}
              {mainTab === 'tp_kj' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
            </button>
            <button onClick={() => setMainTab('schedule')} className={`pb-4 text-sm font-bold transition-all relative ${mainTab === 'schedule' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>
              Jadual Pemantauan
              {mainTab === 'schedule' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
            </button>
            {!isRestricted && (
              <button onClick={() => setMainTab('summary')} className={`pb-4 text-sm font-bold transition-all relative ${mainTab === 'summary' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>
                Rumusan Analisis
                {mainTab === 'summary' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />}
              </button>
            )}
          </>
        )}
      </div>

      {!isDeptView && mainTab === 'analytics' && !isRestricted && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
              <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl"><PresentationChartBarIcon className="h-6 w-6"/></div>
              <div><p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Purata Skor Keseluruhan</p><p className="text-xl font-black text-slate-900">{overallMean}</p></div>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
              <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl"><AcademicCapIcon className="h-6 w-6"/></div>
              <div><p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Telah Dipantau</p><p className="text-xl font-black text-slate-900">{records.length}</p></div>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
              <div className="p-2.5 bg-rose-50 text-rose-600 rounded-xl"><CheckBadgeIcon className="h-6 w-6"/></div>
              <div><p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Peratus Keseluruhan Dipantau</p><p className="text-xl font-black text-slate-900">{overallMonitoredPercentage}</p></div>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 relative group">
              <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl"><UsersIcon className="h-6 w-6"/></div>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status Pemantauan</p>
                <div className="flex items-baseline gap-2">
                  <p className="text-xl font-black text-slate-900">
                    {allLecturers.length - unmonitoredLecturersOverall.length}/{allLecturers.length}
                  </p>
                  {newLecturers.length > 0 && (
                    <span className="text-[9px] font-black text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded-md border border-indigo-100">
                      +{newLecturers.length} Baru
                    </span>
                  )}
                </div>
              </div>
              {unmonitoredLecturersOverall.length > 0 && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-xl p-4 z-50 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-200">
                  <p className="text-[10px] font-black text-rose-600 uppercase mb-2">Belum Dipantau ({unmonitoredLecturersOverall.length})</p>
                  <div className="space-y-1 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                    {unmonitoredLecturersOverall.map(l => (
                      <div key={l.name} className="text-[10px] font-bold text-slate-600 border-b border-slate-50 pb-1">
                        {l.name} <span className="text-[8px] text-slate-400 font-medium">({l.department})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 relative group">
              <div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl"><ExclamationCircleIcon className="h-6 w-6"/></div>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Belum Dipantau</p>
                <p className="text-xl font-black text-slate-900">{unmonitoredLecturersOverall.length}</p>
              </div>
              {unmonitoredLecturersOverall.length > 0 && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-xl p-4 z-50 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-200">
                  <p className="text-[10px] font-black text-orange-600 uppercase mb-2">Senarai Belum Dipantau ({unmonitoredLecturersOverall.length})</p>
                  <div className="space-y-1 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                    {unmonitoredLecturersOverall.map(l => (
                      <div key={l.name} className="text-[10px] font-bold text-slate-600 border-b border-slate-50 pb-1">
                        {l.name} <span className="text-[8px] text-slate-400 font-medium">({l.department})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
              <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl"><BuildingOfficeIcon className="h-6 w-6"/></div>
              <div><p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Jabatan</p><p className="text-xl font-black text-slate-900">{activeDepartments.length}</p></div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 h-[525px] shadow-sm">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-lg font-bold text-slate-800">
                  {isAdminView ? 'Analisis Prestasi Seluruh Kampus' : 'Carta Prestasi Jabatan'}
                </h3>
                <div className="inline-flex p-1 bg-slate-100 rounded-xl">
                  <button onClick={() => setAnalysisType('department')} className={`px-3 py-1.5 text-xs font-bold rounded-lg ${analysisType === 'department' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}>Jabatan</button>
                  <button onClick={() => setAnalysisType('lecturer')} className={`px-3 py-1.5 text-xs font-bold rounded-lg ${analysisType === 'lecturer' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}>Staf</button>
                </div>
              </div>
              <div className="h-[380px] w-full">
                {analysisType === 'department' && (
                  <div className="h-full w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={activeChartData}
                          cx="50%"
                          cy="45%"
                          innerRadius={65}
                          outerRadius={105}
                          paddingAngle={3}
                          dataKey="value"
                          label={({ x, y, textAnchor, name, value }) => {
                            const cleanName = name.includes(' (') ? name.split(' (')[0] : name;
                            const formattedValue = typeof value === 'number' ? (value % 1 === 0 ? value : value.toFixed(2)) : value;
                            return (
                              <text
                                x={x}
                                y={y}
                                textAnchor={textAnchor}
                                dominantBaseline="central"
                                className="text-[8px] font-bold fill-slate-600"
                                style={{ fontSize: '8px', fontWeight: 'bold' }}
                              >
                                {`${cleanName}: ${formattedValue}`}
                              </text>
                            );
                          }}
                          labelLine={true}
                        >
                          {activeChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                          itemStyle={{ color: '#1e293b', fontSize: '11px', fontWeight: 'bold' }}
                          formatter={(value, name) => [`${value}`, `${name}`]} 
                        />
                        <Legend 
                          iconSize={8}
                          layout="horizontal"
                          verticalAlign="bottom"
                          align="center"
                          wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', color: '#64748b', paddingTop: '10px' }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}

                {analysisType === 'lecturer' && (
                  <div className="w-full h-full flex flex-col border border-slate-100 rounded-2xl bg-slate-50/50 p-4 overflow-hidden">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 px-1">Senarai Prestasi Pensyarah & Min</p>
                    <div className="flex-1 overflow-y-auto pr-1 custom-scrollbar">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {lecturerStats.map((item, index) => (
                          <div key={item.name} className="flex items-center justify-between p-2.5 rounded-xl bg-white border border-slate-100 hover:border-indigo-100 hover:shadow-sm transition-all">
                            <div className="flex items-center gap-2.5 overflow-hidden mr-2">
                              <span className="text-[10px] font-bold text-slate-400 w-4 text-center shrink-0">{index + 1}</span>
                              <div className="overflow-hidden">
                                <p className="text-[11px] font-black text-slate-800 leading-snug whitespace-normal break-words" title={item.name}>
                                  {item.name}
                                </p>
                                <p className="text-[8px] font-bold text-indigo-500 truncate mt-0.5">{item.department}</p>
                              </div>
                            </div>
                            <div className="text-right shrink-0">
                              <span className="inline-flex items-center px-2 py-0.5 rounded-lg text-[10px] font-black bg-indigo-50 text-indigo-700">
                                {item.value.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-indigo-600 p-6 rounded-2xl shadow-lg shadow-indigo-100 text-white relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-lg font-bold flex items-center gap-2 mb-4"><CalendarIcon className="h-5 w-5" /> Jadual Akan Datang</h3>
                  <div className="space-y-3">
                    {upcomingSchedules.length > 0 ? upcomingSchedules.map(s => (
                      <div key={s.id} className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/20">
                        <p className="text-xs font-black">{s.lecturerName}</p>
                        <div className="flex items-center gap-2 text-[10px] mt-1 opacity-80">
                          <ClockIcon className="h-3 w-3" />
                          <span>{formatDate(s.date)} • {s.time}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] mt-0.5 opacity-80">
                          <MapPinIcon className="h-3 w-3" />
                          <span>{s.location}</span>
                        </div>
                      </div>
                    )) : (
                      <p className="text-xs italic opacity-70">Tiada jadual dalam masa terdekat.</p>
                    )}
                  </div>
                  <button onClick={() => setMainTab('schedule')} className="mt-4 text-[10px] font-black uppercase tracking-widest bg-white text-indigo-600 px-4 py-2 rounded-lg w-full text-center hover:bg-indigo-50 transition-colors">
                    Lihat Semua Jadual
                  </button>
                </div>
                <div className="absolute -bottom-4 -right-4 opacity-10"><CalendarDaysIcon className="h-32 w-32" /></div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 flex flex-col h-[285px] shadow-sm overflow-hidden">
                <div className="p-4 border-b border-slate-100">
                  <h3 className="text-sm font-bold text-slate-800">Carian Rekod Pantas</h3>
                </div>
                <div className="p-4 space-y-2 overflow-y-auto">
                  <div className="relative">
                    <MagnifyingGlassIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="text" placeholder="Cari pensyarah..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500" />
                  </div>
                  <div className="divide-y divide-slate-50">
                    {filteredRecords.slice(0, 5).map(record => (
                      <div key={record.id} className="py-2.5 flex justify-between items-center group">
                        <div className="pr-2">
                          <p className="text-[11px] font-bold text-slate-800">{record.lecturerName}</p>
                          <p className="text-[9px] text-slate-400">{formatDate(record.date)} • {record.code}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <button 
                            onClick={() => onEditRecord(record)} 
                            className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg border border-emerald-200 transition-colors shadow-sm"
                            title="Kemaskini Rekod Penilaian"
                          >
                            <PencilSquareIcon className="h-3.5 w-3.5" />
                          </button>
                          <button 
                            onClick={() => generatePDF(record, 'view')} 
                            className="p-1.5 bg-slate-50 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-indigo-600 transition-colors"
                            title="Lihat PDF"
                          >
                            <EyeIcon className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 flex flex-col shadow-sm overflow-hidden">
             <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <h3 className="text-lg font-bold text-slate-800">Senarai Penuh Rekod Telah Dipantau</h3>
                <div className="flex items-center gap-3">
                  {(userRole === 'admin' || activeDepartments.length > 1) && (
                    <div className="relative">
                      <FunnelIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <select 
                        value={recordsDeptFilter} 
                        onChange={e => setRecordsDeptFilter(e.target.value)}
                        className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-[10px] font-black uppercase text-slate-600 outline-none w-full sm:w-48 appearance-none"
                      >
                        <option value="all">Semua Jabatan</option>
                        {activeDepartments.map(dept => <option key={dept} value={dept}>{dept}</option>)}
                      </select>
                    </div>
                  )}
                  <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-all whitespace-nowrap">
                    <input type="checkbox" checked={onlyKJRecords} onChange={e => setOnlyKJRecords(e.target.checked)} className="h-4 w-4 text-rose-600 border-slate-300 rounded" />
                    <span className="text-[10px] font-black uppercase text-slate-600">Hanya KJ</span>
                  </label>
                </div>
             </div>
             {selectedRecordIds.size > 0 && (
               <div className="mb-4 p-3.5 bg-indigo-50 border border-indigo-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-200">
                 <div className="flex items-center gap-2">
                   <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-pulse" />
                   <span className="text-xs font-bold text-indigo-900">
                     {selectedRecordIds.size} rekod penilaian dipilih
                   </span>
                 </div>
                 <div className="flex items-center gap-2 flex-wrap">
                   <button
                     onClick={() => setSelectedRecordIds(new Set())}
                     className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
                   >
                     Batal Pilihan
                   </button>
                   <button
                     onClick={handleEditSelectedRecord}
                     className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all active:scale-95"
                     title={selectedRecordIds.size === 1 ? 'Kemaskini rekod penilaian ini' : 'Kemaskini rekod penilaian pertama yang dipilih'}
                   >
                     <PencilSquareIcon className="h-4 w-4" /> Kemaskini Rekod {selectedRecordIds.size > 1 ? '(Pertama)' : ''}
                   </button>
                   <button
                     onClick={handleBatchDeleteRecords}
                     className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md transition-all active:scale-95"
                     title="Padam semua rekod penilaian yang dipilih secara kekal"
                   >
                     <TrashIcon className="h-4 w-4" /> Padam Rekod Dipilih ({selectedRecordIds.size})
                   </button>
                 </div>
               </div>
             )}
             <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-500 font-bold border-b border-slate-100 uppercase text-[10px] tracking-widest">
                      <th className="w-12 px-4 py-3 text-center">
                        <input 
                          type="checkbox"
                          checked={filteredRecords.length > 0 && filteredRecords.every(r => selectedRecordIds.has(r.id))}
                          onChange={() => toggleSelectAllRecords(filteredRecords)}
                          className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                          title="Pilih Semua Rekod"
                        />
                      </th>
                      <th className="px-6 py-3">Maklumat Telah Dipantau</th>
                      <th className="px-6 py-3 text-right">Tindakan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredRecords.map(record => {
                      const scores = Object.values(record.scores) as number[];
                      const avg = (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(2);
                      const hasBothSignatures = !!record.lecturerSignature && !!record.evaluatorSignature;
                      return (
                        <tr key={record.id} className={`transition-all duration-300 ${
                          selectedRecordIds.has(record.id)
                            ? 'bg-indigo-50/50'
                            : (recentlySavedId === record.id 
                                ? (recentlySavedAction === 'updated' 
                                    ? 'bg-indigo-50/80 border-l-4 border-l-indigo-600 shadow-sm' 
                                    : 'bg-emerald-50/80 border-l-4 border-l-emerald-500 shadow-sm') 
                                : 'hover:bg-slate-50')
                        }`}>
                          <td className="w-12 px-4 py-4 text-center">
                            <input 
                              type="checkbox"
                              checked={selectedRecordIds.has(record.id)}
                              onChange={() => toggleSelectRecord(record.id)}
                              className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                            />
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-bold text-slate-800">{record.lecturerName}</p>
                              {record.lecturerName.includes('(KJ)') && <span className="bg-rose-50 text-rose-600 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-rose-100">KJ</span>}
                              {recentlySavedId === record.id && (
                                <span className={`text-white text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse shadow-sm ${
                                  recentlySavedAction === 'updated' ? 'bg-indigo-600' : 'bg-emerald-600'
                                }`}>
                                  {recentlySavedAction === 'updated' ? '🔄 Berjaya Dikemaskini' : '✨ Baru Disimpan'}
                                </span>
                              )}
                              {hasBothSignatures ? (
                                <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 text-[9px] font-bold px-2 py-0.5 rounded-md border border-emerald-200">
                                  <CheckBadgeIcon className="h-3 w-3 text-emerald-600" /> 2 Tandatangan Disimpan
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 text-[9px] font-bold px-2 py-0.5 rounded-md border border-amber-200">
                                  Tandatangan Belum Lengkap
                                </span>
                              )}
                            </div>
                            <p className="text-[10px] text-slate-400 uppercase mt-1">
                              {formatDate(record.date)} • {record.code} • <span className="text-indigo-600 font-black">SKOR: {avg}</span>
                              {record.timestamp && (
                                <span className="text-slate-400 font-normal ml-2 lowercase">
                                  (disimpan {new Date(record.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                                </span>
                              )}
                            </p>
                          </td>
                          <td className="px-6 py-4 flex justify-end items-center gap-1.5">
                            <button onClick={() => generatePDF(record, 'view')} className="flex items-center gap-1 px-2 py-1 bg-white border border-indigo-200 text-indigo-600 rounded text-xs font-bold hover:bg-indigo-50 transition-colors"><EyeIcon className="h-3.5 w-3.5" /> Lihat</button>
                            <button onClick={() => generatePDF(record, 'view')} className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded text-xs font-bold hover:bg-slate-50 transition-colors"><PrinterIcon className="h-3.5 w-3.5" /> Cetak</button>
                            <button onClick={() => generateAISummary(record)} className="flex items-center gap-1 px-2 py-1 bg-amber-500 text-white rounded text-xs font-bold hover:bg-amber-600 transition-colors"><SparklesIcon className="h-3.5 w-3.5" /> Rumusan</button>
                            <button onClick={() => generatePDF(record, 'save')} className="flex items-center gap-1 px-2 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded text-xs font-bold hover:bg-emerald-100 transition-colors"><ArrowDownTrayIcon className="h-3.5 w-3.5" /> Muat Turun</button>
                            <button 
                              onClick={() => onEditRecord(record)} 
                              className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold transition-all shadow-sm active:scale-95" 
                              title="Kemaskini Rekod Penilaian Ini"
                            >
                              <PencilSquareIcon className="h-3.5 w-3.5" /> Kemaskini
                            </button>
                            {isAdminView && (
                            <button 
                              onClick={() => handleSaveToDrive(record)} 
                              className={`p-1.5 transition-colors ${isSavingToDrive === record.id ? 'text-indigo-600 animate-spin' : 'text-emerald-500 hover:text-emerald-600'}`} 
                              title="Simpan ke Folder Google Drive Admin"
                            >
                              <CloudArrowUpIcon className="h-4 w-4" />
                            </button>
                          )}
                          <button 
                            onClick={() => onDeleteRecord(record.id)} 
                            className="flex items-center gap-1 px-2.5 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 hover:text-rose-700 rounded text-xs font-bold transition-all shadow-sm active:scale-95" 
                            title="Padam Rekod Penilaian Ini"
                          >
                            <TrashIcon className="h-3.5 w-3.5" /> Padam Rekod
                          </button>
                          </td>
                        </tr>
                      );
                    })}
                    {filteredRecords.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-6 py-12 text-center text-slate-400 italic">
                          Tiada rekod penilaian ditemui untuk carian ini.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
             </div>
          </div>
        </>
      )}

      {!isDeptView && mainTab === 'status' && !isRestricted && (
        <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
          {newLecturers.length > 0 && (
            <div className="bg-indigo-50 border border-indigo-100 rounded-3xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white rounded-2xl shadow-sm text-indigo-600">
                  <SparklesIcon className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-indigo-900 uppercase tracking-tight">Pensyarah Baru Ditambah</h4>
                  <p className="text-[10px] text-indigo-600 font-bold">Terdapat {newLecturers.length} pensyarah baru yang telah dimasukkan ke dalam sistem.</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 justify-center md:justify-end max-w-md">
                {newLecturers.map(l => (
                  <span key={l.name} className="px-2 py-1 bg-white border border-indigo-100 text-[9px] font-black text-indigo-700 rounded-lg shadow-sm">
                    {l.name}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
              <div className="flex justify-between items-center mb-6">
                 <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2"><CheckBadgeIcon className="h-6 w-6 text-rose-600" /> Pemantauan Ketua Jabatan (TP)</h3>
                 <div className="text-right">
                    <p className="text-2xl font-black text-slate-900">{kjMonitoringStats.monitored} / {kjMonitoringStats.total}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">KJ Selesai Dipantau</p>
                 </div>
              </div>
              <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden mb-8 border border-slate-200">
                <div className="h-full bg-rose-500 transition-all duration-1000" style={{ width: `${kjMonitoringStats.percentage}%` }} />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex flex-col">
                    <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-3">KJ Sudah Dipantau</p>
                    <div className="space-y-1.5 overflow-y-auto max-h-[200px] pr-2 custom-scrollbar">
                       {allLecturers.filter(l => l.name.includes('(KJ)') && records.some(r => r.lecturerName === l.name)).map(kj => (
                        <div key={kj.name} className="flex items-center justify-between px-3 py-2 bg-white border border-emerald-100 rounded-xl">
                          <div className="flex items-center gap-2">
                            <CheckBadgeIcon className="h-3.5 w-3.5 text-emerald-500" />
                            <span className="text-[11px] font-bold text-emerald-800">{kj.name}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            {records.filter(r => r.lecturerName.toLowerCase() === kj.name.toLowerCase()).length > 1 && (
                              <span className="text-[8px] font-black bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded uppercase">
                                {records.filter(r => r.lecturerName.toLowerCase() === kj.name.toLowerCase()).length} Rekod
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                      {allLecturers.filter(l => l.name.includes('(KJ)') && records.some(r => r.lecturerName === l.name)).length === 0 && (
                        <p className="text-[10px] text-slate-400 italic">Belum ada rekod.</p>
                      )}
                    </div>
                  </div>
                  <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex flex-col">
                    <p className="text-[10px] font-black text-rose-600 uppercase tracking-widest mb-3">KJ Belum Dipantau</p>
                    <div className="space-y-1.5 overflow-y-auto max-h-[200px] pr-2 custom-scrollbar">
                       {kjMonitoringStats.unmonitored.map(kj => (
                        <div key={kj.name} className="flex items-center justify-between px-3 py-2 bg-white border border-rose-100 rounded-xl">
                          <div className="flex items-center gap-2">
                            <ClockIcon className="h-3.5 w-3.5 text-rose-400" />
                            <span className="text-[11px] font-bold text-rose-800">{kj.name}</span>
                          </div>
                        </div>
                      ))}
                      {kjMonitoringStats.unmonitored.length === 0 && (
                        <p className="text-[10px] text-emerald-600 font-bold">Semua KJ telah dipantau! ✨</p>
                      )}
                    </div>
                  </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
              <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2"><ChartBarSquareIcon className="h-6 w-6 text-indigo-600" /> Rumusan Jabatan</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {departmentMonitoringStats.map((dept, idx) => (
                  <div key={idx} className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-3 relative overflow-hidden">
                    {dept.kjMonitored && <div className="absolute top-2 right-2 text-rose-600"><CheckBadgeIcon className="h-5 w-5" /></div>}
                    <div className="flex justify-between items-center">
                      <h4 className="text-sm font-black text-slate-800">{dept.name}</h4>
                      <div className="flex items-center gap-1.5">
                        <button 
                          onClick={() => {
                            setSelectedDepartment(dept.name);
                            setMainTab('status');
                          }}
                          className="text-[10px] font-black text-white bg-indigo-600 hover:bg-indigo-700 px-2 py-0.5 rounded-lg shadow-sm transition-all active:scale-95"
                          title={`Buka Paparan Jabatan untuk ${dept.name}`}
                        >
                          Paparan Jabatan
                        </button>
                        <button 
                          onClick={() => setSelectedDeptDetails(dept.name)}
                          className="text-[10px] font-bold text-slate-500 hover:underline"
                        >
                          Perincian ({dept.total})
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase">
                      <span>{dept.monitored} / {dept.total} Dipantau</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden"><div className="h-full bg-indigo-500" style={{ width: `${dept.percentage}%` }} /></div>
                    
                    {dept.newMonitoredNames.length > 0 && (
                      <div className="mt-2 p-2 bg-indigo-50/50 rounded-xl border border-indigo-100/50">
                        <p className="text-[9px] font-black text-indigo-600 uppercase mb-1 flex items-center gap-1">
                          <SparklesIcon className="h-2.5 w-2.5" /> Baru Selesai ({dept.newMonitoredNames.length})
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {dept.newMonitoredNames.map(name => (
                            <span key={name} className="px-1.5 py-0.5 bg-white border border-indigo-100 text-[9px] font-bold text-indigo-700 rounded-md">
                              {name}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {dept.unmonitoredNames.length > 0 && (
                      <div className="mt-3 p-3 bg-rose-50/50 rounded-xl border border-rose-100/50">
                        <p className="text-[10px] font-black text-rose-600 uppercase mb-2 flex items-center gap-1">
                          <ExclamationCircleIcon className="h-3 w-3" /> Belum Dipantau ({dept.unmonitoredNames.length})
                        </p>
                        <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto pr-1 custom-scrollbar">
                          {dept.unmonitoredNames.map(name => (
                            <span key={name} className="px-2 py-0.5 bg-white border border-rose-100 text-[10px] font-bold text-slate-600 rounded-lg">
                              {name}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase">
                      <span>{dept.monitored} Dipantau</span>
                      <button 
                        onClick={() => handleBulkExportToDrive(dept.name)}
                        disabled={isBulkSaving === dept.name}
                        className={`flex items-center gap-1 px-2 py-1 rounded-lg border transition-all ${isBulkSaving === dept.name ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-200 text-indigo-600 hover:bg-indigo-50'}`}
                        title="Eksport Semua Rekod Jabatan ke Folder Admin"
                      >
                        {isBulkSaving === dept.name ? (
                          <><ArrowPathIcon className="h-3 w-3 animate-spin" /> Eksport...</>
                        ) : (
                          <><ArchiveBoxArrowDownIcon className="h-3 w-3" /> Eksport Fail</>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
              <div>
                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2"><UsersIcon className="h-6 w-6 text-indigo-600" /> Pengurusan Pensyarah</h3>
                <p className="text-xs text-slate-400 font-bold mt-1 uppercase">Semakan status pemantauan pensyarah mengikut jabatan</p>
              </div>
              <div className="flex flex-wrap gap-2 w-full md:w-auto items-center">
                {/* Status Filter Pills */}
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  <button 
                    type="button"
                    onClick={() => setMonitoringStatusFilter('all')} 
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${monitoringStatusFilter === 'all' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
                  >
                    Semua ({allMonitoringStatus.length})
                  </button>
                  <button 
                    type="button"
                    onClick={() => setMonitoringStatusFilter('monitored')} 
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${monitoringStatusFilter === 'monitored' ? 'bg-emerald-600 text-white shadow-sm' : 'text-emerald-700 hover:bg-emerald-50'}`}
                    title="Paparkan hanya rekod pensyarah yang telah dipantau"
                  >
                    <CheckBadgeIcon className="h-3.5 w-3.5" /> Telah Dipantau ({monitoredLecturersCount})
                  </button>
                  <button 
                    type="button"
                    onClick={() => setMonitoringStatusFilter('unmonitored')} 
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${monitoringStatusFilter === 'unmonitored' ? 'bg-rose-600 text-white shadow-sm' : 'text-rose-700 hover:bg-rose-50'}`}
                    title="Paparkan pensyarah yang belum dipantau"
                  >
                    Belum ({unmonitoredLecturersCount})
                  </button>
                </div>

                <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-all">
                  <input type="checkbox" checked={onlyKJ} onChange={e => setOnlyKJ(e.target.checked)} className="h-4 w-4 text-rose-600 border-slate-300 rounded" />
                  <span className="text-[10px] font-black uppercase text-slate-600">Hanya KJ</span>
                </label>
                {(userRole === 'admin' || activeDepartments.length > 1) && (
                  <div className="relative">
                    <FunnelIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <select 
                      value={selectedDeptFilter} 
                      onChange={e => setSelectedDeptFilter(e.target.value)}
                      className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 outline-none w-full sm:w-48 appearance-none"
                    >
                      <option value="all">Semua Jabatan</option>
                      {activeDepartments.map(dept => <option key={dept} value={dept}>{dept}</option>)}
                    </select>
                  </div>
                )}
                <div className="relative">
                  <MagnifyingGlassIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="text" placeholder="Cari nama..." value={statusSearchTerm} onChange={e => setStatusSearchTerm(e.target.value)} className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                </div>
                {(userRole === 'admin' || canEdit) && (
                  <button onClick={handleNewLecturer} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-md hover:bg-indigo-700 transition-all">
                    <UserPlusIcon className="h-4 w-4" /> Tambah Pensyarah
                  </button>
                )}
              </div>
            </div>
            {selectedLecturerKeys.size > 0 && (() => {
              const selectedMonitored = monitoringStatus.filter(item => 
                selectedLecturerKeys.has(`${item.name}|${item.department}`) && item.isMonitored && item.latestRecord
              );
              return (
                <div className="mb-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-200">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                    <span className="text-xs font-bold text-rose-900">
                      {selectedLecturerKeys.size} pensyarah dipilih {selectedMonitored.length > 0 ? `(${selectedMonitored.length} telah dipantau)` : ''}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={() => setSelectedLecturerKeys(new Set())}
                      className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
                    >
                      Batal Pilihan
                    </button>
                    {selectedMonitored.length === 1 && (
                      <button
                        onClick={() => { onEditRecord(selectedMonitored[0].latestRecord!); setSelectedLecturerKeys(new Set()); }}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all active:scale-95"
                        title="Kemaskini rekod pemantauan bagi pensyarah ini"
                      >
                        <PencilSquareIcon className="h-4 w-4" /> Kemaskini Rekod
                      </button>
                    )}
                    {selectedMonitored.length > 0 && (
                      <button
                        onClick={() => {
                          const ids = selectedMonitored.map(i => i.latestRecord!.id);
                          if (onDeleteMultipleRecords) onDeleteMultipleRecords(ids);
                          else ids.forEach(id => onDeleteRecord(id));
                          setSelectedLecturerKeys(new Set());
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md transition-all active:scale-95"
                        title="Padam rekod pemantauan pensyarah yang telah dipantau ini"
                      >
                        <TrashIcon className="h-4 w-4" /> Padam Rekod Dipantau ({selectedMonitored.length})
                      </button>
                    )}
                    <button
                      onClick={handleBatchDeleteLecturers}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl shadow-sm transition-all active:scale-95"
                      title="Padam profil pensyarah yang dipilih daripada data"
                    >
                      <TrashIcon className="h-4 w-4 text-rose-500" /> Padam Profil ({selectedLecturerKeys.size})
                    </button>
                  </div>
                </div>
              );
            })()}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 uppercase text-[10px]">
                    <th className="w-12 px-4 py-4 text-center">
                      <input 
                        type="checkbox"
                        checked={monitoringStatus.length > 0 && monitoringStatus.every(item => selectedLecturerKeys.has(`${item.name}|${item.department}`))}
                        onChange={() => toggleSelectAllVisible(monitoringStatus)}
                        className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                        title="Pilih Semua Pensyarah"
                      />
                    </th>
                    <th className="px-6 py-4">Nama</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Tindakan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {monitoringStatus.map((item, idx) => (
                    <tr key={idx} className={`hover:bg-slate-50 transition-colors ${selectedLecturerKeys.has(`${item.name}|${item.department}`) ? 'bg-indigo-50/50' : ''}`}>
                      <td className="w-12 px-4 py-4 text-center">
                        <input 
                          type="checkbox"
                          checked={selectedLecturerKeys.has(`${item.name}|${item.department}`)}
                          onChange={() => toggleSelectLecturer(`${item.name}|${item.department}`)}
                          className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-slate-800">{item.name}</p>
                          {item.isKJ && <span className="bg-rose-50 text-rose-600 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-rose-100">KJ</span>}
                          {!LECTURERS.some(l => l.name.toLowerCase() === item.name.toLowerCase()) && (
                            <span className="bg-indigo-50 text-indigo-600 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-indigo-100 flex items-center gap-0.5">
                              <SparklesIcon className="h-2 w-2" /> Baru
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 font-medium">{item.department}</p>
                      </td>
                      <td className="px-8 py-4">
                        {item.isMonitored ? (
                          <div className="flex flex-col">
                            <span className="text-emerald-600 bg-emerald-50 px-2 py-1 rounded text-[10px] uppercase font-bold border border-emerald-100 inline-block w-fit">Dipantau</span>
                            <span className="text-[10px] text-slate-400 mt-1 font-medium">Skor: {item.avgScore} ({item.count} rekod)</span>
                          </div>
                        ) : (
                          <span className="text-rose-600 bg-rose-50 px-2 py-1 rounded text-[10px] uppercase font-bold border border-rose-100">Belum</span>
                        )}
                      </td>
                      <td className="px-8 py-4 text-right flex justify-end gap-2 items-center">
                         {item.isMonitored && item.latestRecord && (
                           <>
                             <button 
                               onClick={() => generatePDF(item.latestRecord!, 'view')} 
                               className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded text-[10px] font-bold hover:bg-slate-50 transition-colors"
                             >
                               <EyeIcon className="h-3 w-3" /> Lihat PDF
                             </button>
                             <button 
                               onClick={() => generatePDF(item.latestRecord!, 'view')} 
                               className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded text-[10px] font-bold hover:bg-slate-50 transition-colors"
                             >
                               <PrinterIcon className="h-3 w-3" /> Cetak
                             </button>
                             <button onClick={() => generateAISummary(item.name)} className="p-1.5 text-amber-500 hover:text-amber-600" title="Rumusan AI"><SparklesIcon className="h-4 w-4" /></button>
                             {item.count > 1 && (
                               <button 
                                 onClick={() => setSelectedLecturerHistory({ name: item.name, records: item.allRecords })} 
                                 className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-indigo-600 rounded text-[10px] font-bold hover:bg-indigo-50 transition-colors"
                                 title="Lihat Sejarah Pemantauan"
                                >
                                 <ClockIcon className="h-3 w-3" /> Sejarah ({item.count})
                               </button>
                             )}
                             {(isAdminView || canEdit) && (
                               <>
                                 <button onClick={() => onEditRecord(item.latestRecord!)} className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold shadow-sm transition-all active:scale-95" title="Kemaskini Rekod Pemantauan Terkini"><PencilSquareIcon className="h-3 w-3" /> Kemaskini</button>
                                <button 
                                  onClick={() => onDeleteRecord(item.latestRecord!.id)} 
                                  className="flex items-center gap-1 px-2 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded text-[10px] font-bold shadow-sm transition-all active:scale-95" 
                                  title="Padam Rekod Pemantauan Selesai Ini"
                                >
                                  <TrashIcon className="h-3 w-3" /> Padam Rekod
                                </button>
                                 {isAdminView && (
                                   <button 
                                    onClick={() => handleSaveToDrive(item.latestRecord!)} 
                                    className={`p-1.5 transition-colors ${isSavingToDrive === item.latestRecord!.id ? 'text-indigo-600 animate-spin' : 'text-emerald-500 hover:text-emerald-600'}`} 
                                    title="Simpan ke Folder Google Drive Admin"
                                   >
                                      <CloudArrowUpIcon className="h-4 w-4" />
                                   </button>
                                 )}
                               </>
                             )}
                             <button 
                               onClick={() => generatePDF(item.latestRecord!, 'save')} 
                               className="flex items-center gap-1 px-2 py-1 bg-indigo-50 border border-indigo-200 text-indigo-700 rounded text-[10px] font-bold hover:bg-indigo-100 transition-colors"
                             >
                               <ArrowDownTrayIcon className="h-3 w-3" /> Muat Turun PDF
                             </button>
                           </>
                         )}
                         <button onClick={() => handleNewSchedule(item.name)} className="p-1.5 text-indigo-500" title="Daftar Jadual"><CalendarIcon className="h-4 w-4" /></button>
                         {!isRestricted && onStartEvaluation && (
                           <button 
                             onClick={() => onStartEvaluation({ lecturerName: item.name, department: item.department })} 
                             className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold shadow-sm transition-all active:scale-95" 
                             title={`Mula Sesi Penilaian untuk ${item.name}`}
                           >
                             <ClipboardDocumentCheckIcon className="h-3 w-3" /> Nilai
                           </button>
                         )}
                          {(isAdminView || canEdit) && (
                            <button 
                              onClick={() => onDeleteLecturer(item.name, item.department)} 
                              className="flex items-center gap-1 px-2 py-1 bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-slate-500 hover:text-rose-600 rounded text-[10px] font-bold transition-all shadow-sm active:scale-95" 
                              title="Padam Maklumat Pensyarah (Jika Berlaku Kesilapan)"
                            >
                              <TrashIcon className="h-3 w-3" /> Padam Pensyarah
                            </button>
                          )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Department View - Status Penilaian */}
      {isDeptView && effectiveTab === 'status' && !isRestricted && (
        <div className="space-y-8 animate-in fade-in duration-500">
          {/* Department Banner & Summary KPI Cards */}
          <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/20 text-white backdrop-blur-sm border border-white/20">
                      Paparan Jabatan Sahaja
                    </span>
                    {isAdminView && (
                      <button 
                        onClick={() => setSelectedDepartment('all')}
                        className="text-xs text-indigo-200 hover:text-white underline font-bold transition-colors"
                      >
                        ← Kembali ke Seluruh Kampus
                      </button>
                    )}
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-black tracking-tight">{currentDept}</h3>
                  <p className="text-xs text-indigo-200 mt-1 font-medium">
                    Status penilaian dan pendaftaran jadual pensyarah di {currentDept} sahaja.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => handleNewSchedule()} 
                    className="flex items-center gap-2 px-4 py-2.5 bg-white text-indigo-900 hover:bg-indigo-50 rounded-xl text-xs font-black shadow-md transition-all active:scale-95"
                  >
                    <CalendarIcon className="h-4 w-4 text-indigo-600" />
                    Daftar Jadual ({currentDept})
                  </button>
                  <button 
                    onClick={handleNewLecturer} 
                    className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black border border-indigo-400 shadow-md transition-all active:scale-95"
                  >
                    <UserPlusIcon className="h-4 w-4" />
                    + Tambah Pensyarah
                  </button>
                </div>
              </div>

              {/* Department KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
                <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                  <p className="text-[10px] font-black uppercase tracking-widest text-indigo-200">Jumlah Pensyarah</p>
                  <p className="text-2xl font-black text-white mt-1">{deptStats?.total || 0}</p>
                  <p className="text-[9px] text-indigo-300 font-medium">Pensyarah di {currentDept}</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                  <p className="text-[10px] font-black uppercase tracking-widest text-emerald-300">Telah Dinilai</p>
                  <p className="text-2xl font-black text-emerald-400 mt-1">{deptStats?.monitoredCount || 0}</p>
                  <p className="text-[9px] text-emerald-200 font-medium">Selesai dipantau</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                  <p className="text-[10px] font-black uppercase tracking-widest text-rose-300">Belum Dinilai</p>
                  <p className="text-2xl font-black text-rose-400 mt-1">{deptStats?.unmonitoredCount || 0}</p>
                  <p className="text-[9px] text-rose-200 font-medium">Menunggu pemantauan</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                  <p className="text-[10px] font-black uppercase tracking-widest text-indigo-200">Peratus Selesai</p>
                  <p className="text-2xl font-black text-white mt-1">{deptStats?.percentage || 0}%</p>
                  <p className="text-[9px] text-indigo-300 font-medium">Kadar pemantauan</p>
                </div>
                <div className="col-span-2 sm:col-span-1 bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                  <p className="text-[10px] font-black uppercase tracking-widest text-amber-300">Ketua Jabatan (KJ)</p>
                  <p className="text-sm font-black text-white mt-1 truncate" title={deptStats?.kj?.name || 'Tiada penama KJ'}>
                    {deptStats?.kj ? deptStats.kj.name.replace(' (KJ)', '').replace('(KJ)', '') : 'Tiada Penama'}
                  </p>
                  <span className={`inline-block mt-1 px-2 py-0.5 rounded text-[8px] font-black uppercase ${
                    deptStats?.kjMonitored ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' : 'bg-rose-500/20 text-rose-300 border border-rose-400/30'
                  }`}>
                    {deptStats?.kjMonitored ? '✓ Selesai Dipantau' : '⏳ Belum Dipantau'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Lecturer Monitoring Status Table (Department Lecturers Only) */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                  <UsersIcon className="h-6 w-6 text-indigo-600" /> 
                  Status Penilaian Pensyarah ({currentDept})
                </h3>
                <p className="text-xs text-slate-400 font-bold mt-1 uppercase">
                  Semakan status pemantauan bagi semua pensyarah di {currentDept} sahaja
                </p>
              </div>
              <div className="flex flex-wrap gap-2 w-full md:w-auto items-center">
                {/* Status Filter Pills */}
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  <button 
                    type="button"
                    onClick={() => setMonitoringStatusFilter('all')} 
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${monitoringStatusFilter === 'all' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
                  >
                    Semua ({allMonitoringStatus.length})
                  </button>
                  <button 
                    type="button"
                    onClick={() => setMonitoringStatusFilter('monitored')} 
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${monitoringStatusFilter === 'monitored' ? 'bg-emerald-600 text-white shadow-sm' : 'text-emerald-700 hover:bg-emerald-50'}`}
                    title="Paparkan hanya rekod pensyarah jabatan ini yang telah dipantau"
                  >
                    <CheckBadgeIcon className="h-3.5 w-3.5" /> Telah Dipantau ({monitoredLecturersCount})
                  </button>
                  <button 
                    type="button"
                    onClick={() => setMonitoringStatusFilter('unmonitored')} 
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${monitoringStatusFilter === 'unmonitored' ? 'bg-rose-600 text-white shadow-sm' : 'text-rose-700 hover:bg-rose-50'}`}
                    title="Paparkan pensyarah yang belum dipantau"
                  >
                    Belum ({unmonitoredLecturersCount})
                  </button>
                </div>

                <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-all">
                  <input type="checkbox" checked={onlyKJ} onChange={e => setOnlyKJ(e.target.checked)} className="h-4 w-4 text-rose-600 border-slate-300 rounded" />
                  <span className="text-[10px] font-black uppercase text-slate-600">Hanya KJ</span>
                </label>
                <div className="relative flex-1 sm:flex-initial">
                  <MagnifyingGlassIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="text" placeholder="Cari nama pensyarah..." value={statusSearchTerm} onChange={e => setStatusSearchTerm(e.target.value)} className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <button onClick={handleNewLecturer} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-indigo-700 transition-all">
                  <UserPlusIcon className="h-4 w-4" /> + Tambah Pensyarah
                </button>
              </div>
            </div>

            {selectedLecturerKeys.size > 0 && (() => {
              const selectedMonitored = monitoringStatus.filter(item => 
                selectedLecturerKeys.has(`${item.name}|${item.department}`) && item.isMonitored && item.latestRecord
              );
              return (
                <div className="mb-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-200">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                    <span className="text-xs font-bold text-rose-900">
                      {selectedLecturerKeys.size} pensyarah dipilih {selectedMonitored.length > 0 ? `(${selectedMonitored.length} telah dipantau)` : ''}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={() => setSelectedLecturerKeys(new Set())}
                      className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
                    >
                      Batal Pilihan
                    </button>
                    {selectedMonitored.length === 1 && (
                      <button
                        onClick={() => { onEditRecord(selectedMonitored[0].latestRecord!); setSelectedLecturerKeys(new Set()); }}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all active:scale-95"
                        title="Kemaskini rekod pemantauan bagi pensyarah ini"
                      >
                        <PencilSquareIcon className="h-4 w-4" /> Kemaskini Rekod
                      </button>
                    )}
                    {selectedMonitored.length > 0 && (
                      <button
                        onClick={() => {
                          const ids = selectedMonitored.map(i => i.latestRecord!.id);
                          if (onDeleteMultipleRecords) onDeleteMultipleRecords(ids);
                          else ids.forEach(id => onDeleteRecord(id));
                          setSelectedLecturerKeys(new Set());
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md transition-all active:scale-95"
                        title="Padam rekod pemantauan pensyarah yang telah dipantau ini"
                      >
                        <TrashIcon className="h-4 w-4" /> Padam Rekod Dipantau ({selectedMonitored.length})
                      </button>
                    )}
                    <button
                      onClick={handleBatchDeleteLecturers}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl shadow-sm transition-all active:scale-95"
                      title="Padam profil pensyarah yang dipilih daripada data"
                    >
                      <TrashIcon className="h-4 w-4 text-rose-500" /> Padam Profil ({selectedLecturerKeys.size})
                    </button>
                  </div>
                </div>
              );
            })()}

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 uppercase text-[10px]">
                    <th className="w-12 px-4 py-4 text-center">
                      <input 
                        type="checkbox"
                        checked={monitoringStatus.length > 0 && monitoringStatus.every(item => selectedLecturerKeys.has(`${item.name}|${item.department}`))}
                        onChange={() => toggleSelectAllVisible(monitoringStatus)}
                        className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                        title="Pilih Semua Pensyarah"
                      />
                    </th>
                    <th className="px-6 py-4">Nama Pensyarah ({currentDept})</th>
                    <th className="px-6 py-4">Status Penilaian</th>
                    <th className="px-6 py-4 text-right">Tindakan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {monitoringStatus.map((item, idx) => (
                    <tr key={idx} className={`hover:bg-slate-50 transition-colors ${selectedLecturerKeys.has(`${item.name}|${item.department}`) ? 'bg-indigo-50/50' : ''}`}>
                      <td className="w-12 px-4 py-4 text-center">
                        <input 
                          type="checkbox"
                          checked={selectedLecturerKeys.has(`${item.name}|${item.department}`)}
                          onChange={() => toggleSelectLecturer(`${item.name}|${item.department}`)}
                          className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-slate-800">{item.name}</p>
                          {item.isKJ && <span className="bg-rose-50 text-rose-600 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-rose-100">KJ</span>}
                          {!LECTURERS.some(l => l.name.toLowerCase() === item.name.toLowerCase()) && (
                            <span className="bg-indigo-50 text-indigo-600 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-indigo-100 flex items-center gap-0.5">
                              <SparklesIcon className="h-2 w-2" /> Baru
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 font-medium">{item.department}</p>
                      </td>
                      <td className="px-6 py-4">
                        {item.isMonitored ? (
                          <div className="flex flex-col">
                            <span className="text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg text-[10px] uppercase font-black border border-emerald-200 inline-block w-fit">
                              ✓ Dipantau
                            </span>
                            <span className="text-[10px] text-slate-500 mt-1 font-bold">
                              Purata Skor: <span className="text-indigo-600 font-black">{item.avgScore}</span> ({item.count} rekod)
                            </span>
                          </div>
                        ) : (
                          <span className="text-rose-600 bg-rose-50 px-2.5 py-1 rounded-lg text-[10px] uppercase font-bold border border-rose-100">
                            ⏳ Belum Dinilai
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-1.5 items-center flex-wrap">
                          {item.isMonitored && item.latestRecord && (
                            <>
                              <button 
                                onClick={() => generatePDF(item.latestRecord!, 'view')} 
                                className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded text-[10px] font-bold hover:bg-slate-50 transition-colors"
                              >
                                <EyeIcon className="h-3 w-3" /> Lihat PDF
                              </button>
                              <button 
                                onClick={() => generatePDF(item.latestRecord!, 'view')} 
                                className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded text-[10px] font-bold hover:bg-slate-50 transition-colors"
                              >
                                <PrinterIcon className="h-3 w-3" /> Cetak
                              </button>
                              <button onClick={() => generateAISummary(item.name)} className="p-1.5 text-amber-500 hover:text-amber-600" title="Rumusan AI"><SparklesIcon className="h-4 w-4" /></button>
                              {item.count > 1 && (
                                <button 
                                  onClick={() => setSelectedLecturerHistory({ name: item.name, records: item.allRecords })} 
                                  className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-indigo-600 rounded text-[10px] font-bold hover:bg-indigo-50 transition-colors"
                                  title="Lihat Sejarah Pemantauan"
                                >
                                  <ClockIcon className="h-3 w-3" /> Sejarah ({item.count})
                                </button>
                              )}
                              <button onClick={() => onEditRecord(item.latestRecord!)} className="flex items-center gap-1 px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold shadow-sm transition-all" title="Kemaskini Rekod Penilaian"><PencilSquareIcon className="h-3 w-3" /> Kemaskini</button>
                              {(isAdminView || canEdit) && (
                                <button 
                                  onClick={() => onDeleteRecord(item.latestRecord!.id)} 
                                  className="flex items-center gap-1 px-2 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded text-[10px] font-bold shadow-sm transition-all active:scale-95" 
                                  title="Padam Rekod Pemantauan Selesai Ini"
                                >
                                  <TrashIcon className="h-3 w-3" /> Padam Rekod
                                </button>
                              )}
                              <button 
                                onClick={() => generatePDF(item.latestRecord!, 'save')} 
                                className="flex items-center gap-1 px-2 py-1 bg-indigo-50 border border-indigo-200 text-indigo-700 rounded text-[10px] font-bold hover:bg-indigo-100 transition-colors"
                              >
                                <ArrowDownTrayIcon className="h-3 w-3" /> Muat Turun
                              </button>
                            </>
                          )}
                          {!isRestricted && onStartEvaluation && (
                            <button 
                              onClick={() => onStartEvaluation({ lecturerName: item.name, department: item.department })} 
                              className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold shadow-sm transition-all active:scale-95" 
                              title={`Mula Sesi Penilaian untuk ${item.name}`}
                            >
                              <ClipboardDocumentCheckIcon className="h-3 w-3" /> Nilai
                            </button>
                          )}
                          <button onClick={() => handleNewSchedule(item.name)} className="flex items-center gap-1 px-2 py-1 bg-indigo-50 border border-indigo-200 text-indigo-600 rounded text-[10px] font-bold hover:bg-indigo-100" title="Daftar Jadual untuk pensyarah ini">
                            <CalendarIcon className="h-3 w-3" /> Jadual
                          </button>
                          {(isAdminView || canEdit) && (
                            <button 
                              onClick={() => onDeleteLecturer(item.name, item.department)} 
                              className="flex items-center gap-1 px-2 py-1 bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-slate-500 hover:text-rose-600 rounded text-[10px] font-bold transition-all shadow-sm active:scale-95" 
                              title="Padam Maklumat Pensyarah (Jika Berlaku Kesilapan)"
                            >
                              <TrashIcon className="h-3 w-3" /> Padam Pensyarah
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {monitoringStatus.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-slate-400 italic">
                        Tiada pensyarah ditemui untuk carian ini dalam {currentDept}.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Full Evaluation Records of this Department */}
          <div className="bg-white rounded-3xl border border-slate-200 flex flex-col shadow-sm overflow-hidden">
             <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">Senarai Penuh Rekod Penilaian Selesai ({currentDept})</h3>
                  <p className="text-xs text-slate-400 font-bold mt-0.5">Terdapat {filteredRecords.length} rekod penilaian rasmi bagi jabatan ini</p>
                </div>
                <div className="relative w-full sm:w-64">
                  <MagnifyingGlassIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="text" placeholder="Cari pensyarah..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
             </div>
             {selectedRecordIds.size > 0 && (
               <div className="mb-4 p-3.5 bg-indigo-50 border border-indigo-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-200">
                 <div className="flex items-center gap-2">
                   <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-pulse" />
                   <span className="text-xs font-bold text-indigo-900">
                     {selectedRecordIds.size} rekod penilaian dipilih ({currentDept})
                   </span>
                 </div>
                 <div className="flex items-center gap-2 flex-wrap">
                   <button
                     onClick={() => setSelectedRecordIds(new Set())}
                     className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
                   >
                     Batal Pilihan
                   </button>
                   <button
                     onClick={handleEditSelectedRecord}
                     className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all active:scale-95"
                     title={selectedRecordIds.size === 1 ? 'Kemaskini rekod penilaian ini' : 'Kemaskini rekod penilaian pertama yang dipilih'}
                   >
                     <PencilSquareIcon className="h-4 w-4" /> Kemaskini Rekod {selectedRecordIds.size > 1 ? '(Pertama)' : ''}
                   </button>
                   <button
                     onClick={handleBatchDeleteRecords}
                     className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md transition-all active:scale-95"
                     title="Padam semua rekod penilaian yang dipilih secara kekal"
                   >
                     <TrashIcon className="h-4 w-4" /> Padam Rekod Dipilih ({selectedRecordIds.size})
                   </button>
                 </div>
               </div>
             )}
             <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-500 font-bold border-b border-slate-100 uppercase text-[10px] tracking-widest">
                      <th className="w-12 px-4 py-3 text-center">
                        <input 
                          type="checkbox"
                          checked={filteredRecords.length > 0 && filteredRecords.every(r => selectedRecordIds.has(r.id))}
                          onChange={() => toggleSelectAllRecords(filteredRecords)}
                          className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                          title="Pilih Semua Rekod"
                        />
                      </th>
                      <th className="px-6 py-3">Maklumat Penilaian</th>
                      <th className="px-6 py-3 text-right">Tindakan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredRecords.map(record => {
                      const scores = Object.values(record.scores) as number[];
                      const avg = scores.length > 0 ? (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(2) : '0.00';
                      const hasBothSignatures = !!record.lecturerSignature && !!record.evaluatorSignature;
                      return (
                        <tr key={record.id} className={`hover:bg-slate-50 transition-colors ${selectedRecordIds.has(record.id) ? 'bg-indigo-50/50' : ''}`}>
                          <td className="w-12 px-4 py-4 text-center">
                            <input 
                              type="checkbox"
                              checked={selectedRecordIds.has(record.id)}
                              onChange={() => toggleSelectRecord(record.id)}
                              className="h-4 w-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                            />
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-bold text-slate-800">{record.lecturerName}</p>
                              {record.lecturerName.includes('(KJ)') && <span className="bg-rose-50 text-rose-600 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-rose-100">KJ</span>}
                              {hasBothSignatures ? (
                                <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 text-[9px] font-bold px-2 py-0.5 rounded-md border border-emerald-200">
                                  <CheckBadgeIcon className="h-3 w-3 text-emerald-600" /> 2 Tandatangan Disimpan
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 text-[9px] font-bold px-2 py-0.5 rounded-md border border-amber-200">
                                  Tandatangan Belum Lengkap
                                </span>
                              )}
                            </div>
                            <p className="text-[10px] text-slate-400 uppercase mt-1">{formatDate(record.date)} • {record.code} • {record.course} • <span className="text-indigo-600 font-black">SKOR: {avg}</span></p>
                          </td>
                          <td className="px-6 py-4 flex justify-end items-center gap-1.5 flex-wrap">
                            <button onClick={() => generatePDF(record, 'view')} className="flex items-center gap-1 px-2 py-1 bg-white border border-indigo-200 text-indigo-600 rounded text-xs font-bold hover:bg-indigo-50 transition-colors"><EyeIcon className="h-3.5 w-3.5" /> Lihat</button>
                            <button onClick={() => generatePDF(record, 'view')} className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded text-xs font-bold hover:bg-slate-50 transition-colors"><PrinterIcon className="h-3.5 w-3.5" /> Cetak</button>
                            <button onClick={() => generateAISummary(record)} className="flex items-center gap-1 px-2 py-1 bg-amber-500 text-white rounded text-xs font-bold hover:bg-amber-600 transition-colors"><SparklesIcon className="h-3.5 w-3.5" /> Rumusan</button>
                            <button onClick={() => generatePDF(record, 'save')} className="flex items-center gap-1 px-2 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded text-xs font-bold hover:bg-emerald-100 transition-colors"><ArrowDownTrayIcon className="h-3.5 w-3.5" /> Muat Turun</button>
                            <button 
                              onClick={() => onEditRecord(record)} 
                              className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold transition-all shadow-sm active:scale-95" 
                              title="Kemaskini Rekod Penilaian Ini"
                            >
                              <PencilSquareIcon className="h-3.5 w-3.5" /> Kemaskini
                            </button>
                            {isAdminView && (
                              <button 
                                onClick={() => handleSaveToDrive(record)} 
                                className={`p-1.5 transition-colors ${isSavingToDrive === record.id ? 'text-indigo-600 animate-spin' : 'text-emerald-500 hover:text-emerald-600'}`} 
                                title="Simpan ke Folder Google Drive Admin"
                              >
                                <CloudArrowUpIcon className="h-4 w-4" />
                              </button>
                            )}
                            <button 
                              onClick={() => onDeleteRecord(record.id)} 
                              className="flex items-center gap-1 px-2.5 py-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 hover:text-rose-700 rounded text-xs font-bold transition-all shadow-sm active:scale-95" 
                              title="Padam Rekod Penilaian Ini"
                            >
                              <TrashIcon className="h-3.5 w-3.5" /> Padam Rekod
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                    {filteredRecords.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-6 py-12 text-center text-slate-400 italic">
                          Belum ada rekod penilaian bagi {currentDept}.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
             </div>
          </div>
        </div>
      )}

      {effectiveTab === 'schedule' && (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
          <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                  <CalendarDaysIcon className="h-6 w-6 text-indigo-600" /> 
                  Pendaftaran & Jadual Pemantauan {isDeptView ? `(${currentDept})` : ''}
                </h3>
                <p className="text-xs text-slate-400 font-bold mt-1 uppercase">
                  {isDeptView ? `Senarai sesi pemantauan bagi pensyarah ${currentDept} sahaja` : 'Senarai sesi pemantauan bagi semua pensyarah'} • {filteredSchedules.length} Sesi
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                <div className="relative flex-1 sm:w-60">
                  <MagnifyingGlassIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Cari jadual pensyarah..." 
                    value={scheduleSearchTerm} 
                    onChange={e => setScheduleSearchTerm(e.target.value)} 
                    className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none w-full focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-all select-none">
                  <input 
                    type="checkbox" 
                    checked={filteredSchedules.length > 0 && filteredSchedules.every(s => selectedScheduleIds.has(s.id))} 
                    onChange={() => toggleSelectAllSchedules(filteredSchedules)} 
                    className="h-4 w-4 text-rose-600 border-slate-300 rounded cursor-pointer" 
                  />
                  <span className="text-[10px] font-black uppercase text-slate-700">Pilih Semua ({filteredSchedules.length})</span>
                </label>
                <button 
                  type="button"
                  onClick={() => handleDeleteAllSchedules(filteredSchedules)}
                  disabled={filteredSchedules.length === 0}
                  className="flex items-center gap-1.5 px-3 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 hover:text-rose-800 rounded-xl text-xs font-black shadow-xs transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                  title="Padam jadual pemantauan untuk semua pensyarah sekaligus dan selaraskan ke semua peranti"
                >
                  <TrashIcon className="h-4 w-4 text-rose-600" />
                  <span>Padam Jadual Semua Pensyarah ({filteredSchedules.length})</span>
                </button>
                {onSync && (
                  <button 
                    type="button"
                    onClick={onSync}
                    disabled={isSyncing}
                    className="flex items-center gap-1.5 px-3 py-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 rounded-xl text-xs font-black shadow-xs transition-all active:scale-95 disabled:opacity-50"
                    title="Segerak jadual pemantauan serta-merta merentasi semua peranti (Android, iOS, Windows, Mac)"
                  >
                    <ArrowPathIcon className={`h-4 w-4 text-indigo-600 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>{isSyncing ? 'Menyelaraskan...' : 'Segerak Jadual'}</span>
                  </button>
                )}
                <label className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-all select-none">
                  <input type="checkbox" checked={onlyKJSchedule} onChange={e => setOnlyKJSchedule(e.target.checked)} className="h-4 w-4 text-rose-600 border-slate-300 rounded" />
                  <span className="text-[10px] font-black uppercase text-slate-600">Hanya KJ</span>
                </label>
                {!isDeptView && (userRole === 'admin' || activeDepartments.length > 1) && (
                  <div className="relative">
                    <FunnelIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <select 
                      value={scheduleDeptFilter} 
                      onChange={e => setScheduleDeptFilter(e.target.value)}
                      className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 outline-none w-full sm:w-44 appearance-none"
                    >
                      <option value="all">Semua Jabatan</option>
                      {activeDepartments.map(dept => <option key={dept} value={dept}>{dept}</option>)}
                    </select>
                  </div>
                )}
                <button onClick={() => handleNewSchedule()} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-md hover:bg-indigo-700 transition-all active:scale-95">
                  + Daftar Jadual Baru {isDeptView ? `(${currentDept})` : ''}
                </button>
              </div>
            </div>

            {/* Batch delete bar for selected schedules */}
            {selectedScheduleIds.size > 0 && (
              <div className="mb-6 p-4 bg-rose-50/90 border-2 border-rose-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="flex items-center gap-2 text-rose-800 font-bold text-xs sm:text-sm">
                  <CheckCircleIcon className="h-5 w-5 text-rose-600 shrink-0" />
                  <span>{selectedScheduleIds.size} jadual pemantauan dipilih untuk tindakan</span>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    onClick={handleBatchDeleteSchedules}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-md transition-all active:scale-95"
                    title="Padam semua jadual pemantauan yang dipilih untuk pensyarah"
                  >
                    <TrashIcon className="h-4 w-4" /> Padam Jadual Dipilih ({selectedScheduleIds.size})
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedScheduleIds(new Set())}
                    className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-xl text-xs font-bold transition-all"
                  >
                    Batal Pilihan
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredSchedules.length > 0 ? filteredSchedules.map(s => {
                const matchingRecord = records.find(r => 
                  r.lecturerName.trim().toLowerCase() === s.lecturerName.trim().toLowerCase() && 
                  (r.date === s.date || r.code === s.code)
                );
                const isSelected = selectedScheduleIds.has(s.id);
                return (
                  <div key={s.id} className={`p-6 bg-slate-50 border rounded-3xl transition-all relative ${isSelected ? 'border-rose-400 bg-rose-50/20 shadow-sm' : 'border-slate-200 hover:border-indigo-300'}`}>
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-2.5">
                        <label className="p-1 cursor-pointer flex items-center" title="Pilih jadual ini untuk dipadam">
                          <input 
                            type="checkbox" 
                            checked={isSelected} 
                            onChange={() => toggleSelectSchedule(s.id)} 
                            className="h-4 w-4 text-rose-600 border-slate-300 rounded cursor-pointer" 
                          />
                        </label>
                        <div className="p-2 bg-indigo-100 text-indigo-600 rounded-xl">
                          <ClockIcon className="h-5 w-5" />
                        </div>
                      </div>
                      
                      {/* Prominent, always-visible action buttons for all users */}
                      <div className="flex items-center gap-1.5">
                        <button 
                          onClick={() => handleEditSchedule(s)} 
                          className="p-2 bg-white hover:bg-indigo-50 border border-slate-200 text-slate-600 hover:text-indigo-600 rounded-xl shadow-xs transition-all" 
                          title="Kemaskini Jadual Pemantauan Ini"
                        >
                          <PencilSquareIcon className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => onDeleteSchedule(s.id)} 
                          className="p-2 bg-white hover:bg-rose-50 border border-slate-200 text-rose-600 hover:border-rose-300 rounded-xl shadow-xs transition-all active:scale-95" 
                          title="Padam Jadual Pemantauan Pensyarah Ini"
                        >
                          <TrashIcon className="h-4 w-4" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1 mb-4">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-black text-slate-800 leading-tight">{s.lecturerName}</p>
                        {s.lecturerName.includes('(KJ)') && <span className="bg-rose-50 text-rose-600 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-rose-100">KJ</span>}
                        {matchingRecord ? (
                          <span className="bg-emerald-50 text-emerald-700 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-emerald-200">
                            ✓ Selesai Dinilai
                          </span>
                        ) : (
                          <span className="bg-amber-50 text-amber-700 text-[8px] font-black px-1.5 py-0.5 rounded uppercase border border-amber-200">
                            Menunggu Pemantauan
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{s.department}</p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                        <CalendarIcon className="h-3.5 w-3.5 text-indigo-500" />
                        <span>{formatDate(s.date)}</span>
                        <span className="mx-1">•</span>
                        <span>{s.time}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                        <AcademicCapIcon className="h-3.5 w-3.5 text-indigo-500" />
                        <span>{s.code} - {s.course}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-xl w-fit">
                        <MapPinIcon className="h-3.5 w-3.5" />
                        <span>{s.location || 'Bilik Kuliah / Makmal'}</span>
                      </div>
                    </div>

                    {/* Bottom Action Buttons: Always provide clear Padam Jadual button */}
                    {matchingRecord ? (
                      <div className="mt-4 flex flex-wrap gap-2 pt-2 border-t border-slate-200/60">
                        <button 
                          onClick={() => onEditRecord(matchingRecord)} 
                          className="flex-1 min-w-[100px] flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95"
                          title="Kemaskini Rekod Penilaian Ini"
                        >
                          <PencilSquareIcon className="h-3.5 w-3.5" /> Kemaskini Rekod
                        </button>
                        <button 
                          onClick={() => onDeleteRecord(matchingRecord.id)} 
                          className="flex items-center justify-center gap-1 px-3 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95"
                          title="Padam Rekod Penilaian Pensyarah Ini"
                        >
                          <TrashIcon className="h-3.5 w-3.5" /> Padam Rekod
                        </button>
                        <button 
                          onClick={() => onDeleteSchedule(s.id)} 
                          className="flex items-center justify-center gap-1 px-3 py-2 bg-white hover:bg-rose-50 border border-slate-200 text-rose-600 hover:border-rose-200 rounded-xl text-xs font-bold shadow-xs transition-all active:scale-95"
                          title="Padam Jadual Pemantauan Pensyarah Ini"
                        >
                          <TrashIcon className="h-3.5 w-3.5" /> Padam Jadual
                        </button>
                      </div>
                    ) : (
                      <div className="mt-4 flex gap-2 pt-2 border-t border-slate-200/60">
                        {onStartEvaluation && (
                          <button 
                            onClick={() => onStartEvaluation({ 
                              lecturerName: s.lecturerName, 
                              department: s.department, 
                              course: s.course, 
                              code: s.code, 
                              date: s.date 
                            })}
                            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-md shadow-indigo-100 transition-all active:scale-95"
                            title={`Mula Menilai ${s.lecturerName} untuk kursus ${s.code}`}
                          >
                            <ClipboardDocumentCheckIcon className="h-4 w-4" /> Nilai Sesi Ini Sekarang
                          </button>
                        )}
                        <button 
                          onClick={() => onDeleteSchedule(s.id)} 
                          className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded-xl text-xs font-black shadow-xs transition-all active:scale-95"
                          title="Padam Jadual Pemantauan Pensyarah Ini"
                        >
                          <TrashIcon className="h-4 w-4" /> Padam Jadual
                        </button>
                      </div>
                    )}
                  </div>
                );
              }) : (
                <div className="col-span-full py-20 text-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl">
                  <CalendarDaysIcon className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-sm text-slate-500 font-bold italic">Tiada jadual pemantauan ditemui buat masa ini.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {!isDeptView && mainTab === 'summary' && !isRestricted && (
        <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <ChartBarSquareIcon className="h-6 w-6 text-indigo-600" /> Rumusan Analisis Data Terkumpul
              </h3>
              <p className="text-xs text-slate-400 font-bold mt-1 uppercase">
                {analysisDeptFilter === 'all' ? 'Seluruh Kampus' : `Jabatan: ${analysisDeptFilter}`}
              </p>
            </div>
            {(userRole === 'admin' || activeDepartments.length > 1) && (
              <div className="relative">
                <FunnelIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <select 
                  value={analysisDeptFilter} 
                  onChange={e => setAnalysisDeptFilter(e.target.value)}
                  className="pl-9 pr-10 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 outline-none shadow-sm appearance-none min-w-[240px]"
                >
                  <option value="all">Semua Jabatan (Seluruh Kampus)</option>
                  {activeDepartments.map(dept => <option key={dept} value={dept}>{dept}</option>)}
                </select>
                <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <ArrowPathIcon className="h-4 w-4" />
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-emerald-50 border border-emerald-100 p-8 rounded-[2.5rem] space-y-6 shadow-sm">
              <h3 className="text-lg font-black text-emerald-800 uppercase tracking-wider flex items-center gap-3">
                <HandThumbUpIcon className="h-6 w-6" /> Kekuatan Utama
              </h3>
              <div className="space-y-3">
                {strengthsAndWeaknesses.strengths.map((s, idx) => (
                  <div key={idx} className="bg-white p-5 rounded-2xl border border-emerald-200 flex justify-between items-center shadow-sm hover:scale-[1.02] transition-transform">
                    <span className="text-sm font-bold text-emerald-900 pr-4">{s.text}</span>
                    <div className="flex flex-col items-end">
                      <span className="text-xl font-black text-emerald-600">{s.avg}</span>
                      <span className="text-[10px] font-black text-emerald-400 uppercase">Purata Skor</span>
                    </div>
                  </div>
                ))}
                {strengthsAndWeaknesses.strengths.length === 0 && (
                  <p className="text-sm italic text-emerald-600/60">Tiada data kekuatan utama.</p>
                )}
              </div>
            </div>

            <div className="bg-rose-50 border border-rose-100 p-8 rounded-[2.5rem] space-y-6 shadow-sm">
              <h3 className="text-lg font-black text-rose-800 uppercase tracking-wider flex items-center gap-3">
                <ExclamationCircleIcon className="h-6 w-6" /> Keperluan Intervensi
              </h3>
              <div className="space-y-3">
                {strengthsAndWeaknesses.weaknesses.map((w, idx) => (
                  <div key={idx} className="bg-white p-5 rounded-2xl border border-rose-200 flex justify-between items-center shadow-sm hover:scale-[1.02] transition-transform">
                    <span className="text-sm font-bold text-rose-900 pr-4">{w.text}</span>
                    <div className="flex flex-col items-end">
                      <span className="text-xl font-black text-rose-600">{w.avg}</span>
                      <span className="text-[10px] font-black text-rose-400 uppercase">Purata Skor</span>
                    </div>
                  </div>
                ))}
                {strengthsAndWeaknesses.weaknesses.length === 0 && (
                  <p className="text-sm italic text-rose-600/60">Tiada data keperluan intervensi.</p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-sm">
            <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-3">
                <ChartBarSquareIcon className="h-6 w-6 text-indigo-600" /> Analisis Item Terkumpul (Seluruh Kampus)
              </h3>
              <div className="flex items-center gap-4 text-xs font-bold text-slate-400">
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-emerald-500" /> Cemerlang</div>
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-blue-500" /> Baik</div>
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-rose-500" /> Intervensi</div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100 uppercase text-[10px] tracking-widest">
                    <th className="px-8 py-4">Kriteria Penilaian (LAM-PT-03-04)</th>
                    <th className="px-8 py-4 text-center">Purata Skor</th>
                    <th className="px-8 py-4 text-center">Status Prestasi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {itemAnalysis.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-8 py-5 text-sm font-medium text-slate-700 group-hover:text-slate-900">{item.text}</td>
                      <td className="px-8 py-5 text-center font-black text-slate-900 text-lg">{item.avg}</td>
                      <td className="px-8 py-5 text-center">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-[10px] font-black uppercase border ${
                          item.avg >= 4.5 ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                          item.avg >= 4.0 ? 'bg-blue-50 text-blue-600 border-blue-100' : 
                          'bg-rose-50 text-rose-600 border-rose-100'
                        }`}>
                          {item.avg >= 4.5 ? 'Cemerlang' : item.avg >= 4.0 ? 'Baik' : 'Intervensi'}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {itemAnalysis.length === 0 && (
                    <tr>
                      <td colSpan={3} className="px-8 py-20 text-center text-slate-400 italic">Tiada data untuk dipaparkan.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {effectiveTab === 'tp_kj' && (
        !(isTPUser || isTPUnlocked) ? (
          <div className="max-w-md mx-auto my-12 bg-white rounded-3xl border border-slate-200 p-8 sm:p-10 shadow-2xl text-center space-y-6 animate-in fade-in zoom-in-95 duration-300">
            <div className="w-16 h-16 bg-purple-100 text-purple-700 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
              <LockClosedIcon className="h-8 w-8" />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900">Akses Khas Timbalan Pengarah</h3>
              <p className="text-xs text-purple-700 font-bold uppercase tracking-wider mt-1">
                Pemantauan Ketua Jabatan (TP)
              </p>
              <p className="text-xs text-slate-500 mt-3 leading-relaxed">
                Hanya Timbalan Pengarah (TP) sahaja yang boleh log in ke paparan ini untuk pantau Ketua Jabatan dengan password <strong className="text-purple-700">tp</strong>.
              </p>
            </div>
            <form onSubmit={handleTPAuthSubmit} className="space-y-4 pt-2">
              <div className="relative">
                <input
                  type="password"
                  required
                  value={tpPasswordInput}
                  onChange={e => setTpPasswordInput(e.target.value)}
                  placeholder="Masukkan Password TP (tp)"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-center focus:ring-2 focus:ring-purple-500 outline-none transition-all"
                  autoFocus
                />
              </div>
              {tpAuthError && (
                <p className="text-xs font-bold text-rose-600">{tpAuthError}</p>
              )}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setMainTab(isDeptView ? 'status' : 'analytics')}
                  className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-200 transition-all"
                >
                  Kembali
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-purple-600 text-white rounded-xl text-xs font-black hover:bg-purple-700 transition-all shadow-md shadow-purple-200"
                >
                  Log In ke Paparan TP
                </button>
              </div>
            </form>
          </div>
        ) : (
        <div className="space-y-8 animate-in fade-in duration-300">
          {/* Executive Hero Banner */}
          <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-8 sm:p-10 text-white shadow-2xl border border-indigo-900/50">
            <div className="absolute top-0 right-0 -mt-10 -mr-10 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-1/3 -mb-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
              <div className="space-y-3 max-w-3xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 border border-indigo-400/30 rounded-full text-xs font-bold text-indigo-300">
                  <ShieldCheckIcon className="h-4 w-4 text-indigo-400" />
                  <span>Portal Eksekutif Timbalan Pengarah</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                </div>
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                  Pemantauan PdP Ketua Jabatan (TP)
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Paparan khas Timbalan Pengarah bagi pemantauan berterusan Pengajaran & Pembelajaran (PdP) semua Ketua Jabatan di IPG Kampus Pendidikan Teknik mengikut piawaian kualiti instrumen LAM-PT-03-04.
                </p>
                <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 text-white font-medium">
                    <UserCircleIcon className="h-4 w-4 text-emerald-400" />
                    <span>Pemantau Rasmi: <strong className="text-emerald-300">Dr. Muhaida Akmal binti Mohamad (TP)</strong></span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 text-slate-300">
                    <BuildingOfficeIcon className="h-4 w-4 text-indigo-300" />
                    <span>Semua 9 Jabatan Akademik</span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 text-slate-300">
                    <CheckCircleIcon className="h-4 w-4 text-amber-300" />
                    <span>Instrumen LAM-PT-03-04</span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/20 backdrop-blur-md rounded-xl border border-emerald-400/30 text-emerald-300 font-bold">
                    <ShieldCheckIcon className="h-4 w-4" />
                    <span>Log Masuk TP Sah</span>
                  </div>
                  {!isTPUser && isTPUnlocked && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsTPUnlocked(false);
                        setMainTab(isDeptView ? 'status' : 'analytics');
                      }}
                      className="px-2.5 py-1.5 bg-white/10 hover:bg-white/20 border border-white/20 text-slate-200 rounded-xl text-[10px] font-bold transition-all"
                      title="Kunci semula paparan TP"
                    >
                      Kunci Semula
                    </button>
                  )}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row lg:flex-col gap-3 w-full lg:w-auto shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    if (onStartEvaluation) {
                      onStartEvaluation({
                        evaluatorName: 'Dr. Muhaida Akmal binti Mohamad (TP)',
                        date: new Date().toISOString().split('T')[0]
                      });
                    }
                  }}
                  className="flex items-center justify-center gap-2 px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm rounded-2xl shadow-xl shadow-emerald-950/40 transition-all hover:scale-[1.02] active:scale-95"
                >
                  <SparklesIcon className="h-5 w-5" />
                  <span>+ Nilai Ketua Jabatan Sekarang</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingScheduleId(null);
                      setSchedForm({
                        lecturerName: '',
                        date: new Date().toISOString().split('T')[0],
                        time: '08:00',
                        course: '',
                        code: '',
                        location: 'Bilik Kuliah / Makmal'
                      });
                      setShowScheduleModal(true);
                    }}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 border border-white/15 text-white font-bold text-xs rounded-xl backdrop-blur-sm transition-all"
                  >
                    <CalendarDaysIcon className="h-4 w-4 text-indigo-300" />
                    <span>+ Jadual Pemantauan TP</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 border border-white/15 text-white font-bold text-xs rounded-xl backdrop-blur-sm transition-all"
                    title="Cetak Paparan Pemantauan KJ"
                  >
                    <PrinterIcon className="h-4 w-4 text-slate-300" />
                    <span>Cetak</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 5 Executive Metric KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Jumlah Ketua Jabatan</span>
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl"><UsersIcon className="h-5 w-5" /></div>
              </div>
              <div>
                <p className="text-2xl font-black text-slate-900">{kjExecutiveKPIs.total}</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Semua jabatan IPGKPT</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Selesai Dipantau</span>
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl"><CheckBadgeIcon className="h-5 w-5" /></div>
              </div>
              <div>
                <div className="flex items-baseline justify-between">
                  <p className="text-2xl font-black text-emerald-600">{kjExecutiveKPIs.monitored} / {kjExecutiveKPIs.total}</p>
                  <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">{kjExecutiveKPIs.percentage}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-2">
                  <div className="h-full bg-emerald-500 rounded-full transition-all duration-700" style={{ width: `${kjExecutiveKPIs.percentage}%` }} />
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Belum Dipantau</span>
                <div className="p-2 bg-rose-50 text-rose-600 rounded-xl"><ClockIcon className="h-5 w-5" /></div>
              </div>
              <div>
                <p className="text-2xl font-black text-rose-600">{kjExecutiveKPIs.unmonitored}</p>
                <p className="text-xs text-rose-500 font-medium mt-0.5">Perlu dijadualkan oleh TP</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Purata Skor PdP KJ</span>
                <div className="p-2 bg-amber-50 text-amber-600 rounded-xl"><PresentationChartBarIcon className="h-5 w-5" /></div>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <p className="text-2xl font-black text-slate-900">{kjExecutiveKPIs.overallAvgScore}</p>
                  <span className="text-xs text-slate-400 font-bold">/ 5.00</span>
                </div>
                <span className={`inline-block text-[10px] font-black uppercase px-2 py-0.5 rounded mt-1 ${
                  parseFloat(kjExecutiveKPIs.overallAvgScore) >= 4.5 ? 'bg-emerald-100 text-emerald-800' :
                  parseFloat(kjExecutiveKPIs.overallAvgScore) >= 4.0 ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                }`}>
                  {parseFloat(kjExecutiveKPIs.overallAvgScore) >= 4.5 ? 'Cemerlang' : parseFloat(kjExecutiveKPIs.overallAvgScore) >= 4.0 ? 'Baik' : 'Dalam Proses'}
                </span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Integriti Pengesahan</span>
                <div className="p-2 bg-purple-50 text-purple-600 rounded-xl"><ShieldCheckIcon className="h-5 w-5" /></div>
              </div>
              <div>
                <p className="text-2xl font-black text-purple-700">{kjExecutiveKPIs.bothSignedCount} / {kjExecutiveKPIs.monitored || 1}</p>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Tandatangan KJ & TP Sah</p>
              </div>
            </div>
          </div>

          {/* Ketua Jabatan Table Section */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            {/* Header & Controls */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-6 pb-6 border-b border-slate-100">
              <div>
                <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                  <AcademicCapIcon className="h-6 w-6 text-purple-600" />
                  Senarai Pemantauan Ketua Jabatan (KJ)
                </h3>
                <p className="text-xs text-slate-400 font-bold mt-1 uppercase tracking-wider">
                  Semua rekod pemantauan, skor penilaian LAM-PT-03-04 dan jadual sesi TP
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
                {/* Status Filter Pills */}
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setKjStatusFilter('all')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      kjStatusFilter === 'all' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Semua ({kjFullList.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setKjStatusFilter('monitored')}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      kjStatusFilter === 'monitored' ? 'bg-emerald-600 text-white shadow-sm' : 'text-emerald-700 hover:bg-emerald-50'
                    }`}
                  >
                    <CheckBadgeIcon className="h-3.5 w-3.5" />
                    Selesai ({kjExecutiveKPIs.monitored})
                  </button>
                  <button
                    type="button"
                    onClick={() => setKjStatusFilter('unmonitored')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      kjStatusFilter === 'unmonitored' ? 'bg-rose-600 text-white shadow-sm' : 'text-rose-700 hover:bg-rose-50'
                    }`}
                  >
                    Belum ({kjExecutiveKPIs.unmonitored})
                  </button>
                </div>

                {/* Department filter */}
                <div className="relative">
                  <FunnelIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <select
                    value={kjDeptFilter}
                    onChange={e => setKjDeptFilter(e.target.value)}
                    className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 outline-none appearance-none"
                  >
                    <option value="all">Semua Jabatan</option>
                    {DEPARTMENTS.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>

                {/* Search input */}
                <div className="relative flex-1 sm:flex-initial">
                  <MagnifyingGlassIcon className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Cari Ketua Jabatan..."
                    value={kjSearchTerm}
                    onChange={e => setKjSearchTerm(e.target.value)}
                    className="w-full sm:w-56 pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Batch Selection Action Bar */}
            {selectedKJKeys.size > 0 && (() => {
              const selectedKJs = filteredKJList.filter(k => selectedKJKeys.has(`${k.name}|${k.department}`));
              const selectedWithRecords = selectedKJs.filter(k => k.isMonitored && k.latestRecord);
              return (
                <div className="mb-4 p-3.5 bg-purple-50 border border-purple-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-200">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-600 animate-pulse" />
                    <span className="text-xs font-bold text-purple-900">
                      {selectedKJKeys.size} Ketua Jabatan dipilih {selectedWithRecords.length > 0 ? `(${selectedWithRecords.length} mempunyai rekod pemantauan)` : ''}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => setSelectedKJKeys(new Set())}
                      className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
                    >
                      Batal Pilihan
                    </button>
                    {selectedWithRecords.length === 1 && (
                      <button
                        type="button"
                        onClick={() => {
                          const target = selectedWithRecords[0].latestRecord;
                          if (target) onEditRecord(target);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-700 bg-white border border-emerald-300 rounded-xl hover:bg-emerald-50 transition-colors shadow-sm"
                      >
                        <PencilSquareIcon className="h-3.5 w-3.5" />
                        Kemaskini Rekod Terpilih
                      </button>
                    )}
                    {selectedWithRecords.length > 0 && (
                      <button
                        type="button"
                        onClick={handleBatchDeleteKJRecords}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-rose-600 rounded-xl hover:bg-rose-700 transition-colors shadow-sm active:scale-95"
                      >
                        <TrashIcon className="h-3.5 w-3.5" />
                        Padam {selectedWithRecords.length} Rekod Pemantauan Terpilih
                      </button>
                    )}
                  </div>
                </div>
              );
            })()}

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase text-[10px] tracking-wider">
                    <th className="px-4 py-4 w-12 text-center">
                      <input
                        type="checkbox"
                        checked={filteredKJList.length > 0 && filteredKJList.every(k => selectedKJKeys.has(`${k.name}|${k.department}`))}
                        onChange={() => toggleSelectAllVisibleKJs(filteredKJList)}
                        className="w-4 h-4 rounded border-slate-300 text-purple-600 focus:ring-purple-500 cursor-pointer"
                        title="Pilih Semua Ketua Jabatan yang dipaparkan"
                      />
                    </th>
                    <th className="px-3 py-4 w-10 text-center">Bil</th>
                    <th className="px-4 py-4">Ketua Jabatan</th>
                    <th className="px-4 py-4">Jabatan / Unit</th>
                    <th className="px-4 py-4 text-center">Status Pemantauan</th>
                    <th className="px-4 py-4">Sesi PdP Terkini</th>
                    <th className="px-4 py-4 text-center">Skor & Gred</th>
                    <th className="px-4 py-4 text-center">Tandatangan</th>
                    <th className="px-4 py-4 text-center">Jadual TP</th>
                    <th className="px-4 py-4 text-right">Tindakan Pemantauan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredKJList.map((kj, idx) => {
                    const isSelected = selectedKJKeys.has(`${kj.name}|${kj.department}`);
                    return (
                      <tr 
                        key={`${kj.name}-${kj.department}`}
                        className={`hover:bg-purple-50/40 transition-colors ${isSelected ? 'bg-purple-50/60' : ''}`}
                      >
                        {/* Checkbox */}
                        <td className="px-4 py-4 text-center">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleSelectKJ(`${kj.name}|${kj.department}`)}
                            className="w-4 h-4 rounded border-slate-300 text-purple-600 focus:ring-purple-500 cursor-pointer"
                          />
                        </td>

                        {/* Bil */}
                        <td className="px-3 py-4 text-center text-xs font-bold text-slate-400">
                          {idx + 1}
                        </td>

                        {/* Ketua Jabatan Name */}
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 font-black flex items-center justify-center text-xs shrink-0 shadow-sm">
                              {kj.name.charAt(0)}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-bold text-slate-900">{kj.name}</span>
                                <span className="px-1.5 py-0.5 text-[9px] font-black rounded bg-purple-100 text-purple-700 border border-purple-200">
                                  KJ
                                </span>
                              </div>
                              <span className="text-[11px] text-slate-400 font-medium">Ketua Jabatan</span>
                            </div>
                          </div>
                        </td>

                        {/* Department */}
                        <td className="px-4 py-4">
                          <span className="text-xs font-bold text-slate-700">{kj.department}</span>
                        </td>

                        {/* Status Pemantauan Badge */}
                        <td className="px-4 py-4 text-center">
                          {kj.isMonitored ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckBadgeIcon className="h-3.5 w-3.5 text-emerald-600" />
                              Selesai ({kj.recordsCount} Sesi)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-rose-50 text-rose-700 border border-rose-200">
                              <ClockIcon className="h-3.5 w-3.5 text-rose-500" />
                              Belum Dipantau
                            </span>
                          )}
                        </td>

                        {/* Sesi PdP Terkini */}
                        <td className="px-4 py-4">
                          {kj.latestRecord ? (
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-slate-800">{kj.latestRecord.code}</span>
                                <span className="text-[10px] font-bold text-slate-400">• {formatDate(kj.latestRecord.date)}</span>
                              </div>
                              <p className="text-[11px] text-slate-500 truncate max-w-xs">{kj.latestRecord.course}</p>
                              <p className="text-[10px] text-indigo-600 font-medium truncate max-w-xs">
                                Pemantau: {kj.latestRecord.evaluatorName}
                              </p>
                            </div>
                          ) : (
                            <span className="text-xs text-slate-400 italic">Tiada rekod penilaian</span>
                          )}
                        </td>

                        {/* Skor & Gred */}
                        <td className="px-4 py-4 text-center">
                          {kj.isMonitored ? (
                            <div>
                              <div className="text-base font-black text-slate-900">{kj.avgScore.toFixed(2)}</div>
                              <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                kj.avgScore >= 4.5 ? 'bg-emerald-100 text-emerald-800' :
                                kj.avgScore >= 4.0 ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                              }`}>
                                {kj.avgScore >= 4.5 ? 'Cemerlang' : kj.avgScore >= 4.0 ? 'Baik' : 'Sederhana'}
                              </span>
                            </div>
                          ) : (
                            <span className="text-slate-300 font-bold">-</span>
                          )}
                        </td>

                        {/* Tandatangan Digital */}
                        <td className="px-4 py-4 text-center">
                          {kj.latestRecord ? (
                            <div className="flex flex-col items-center gap-1">
                              <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                kj.hasLecturerSig ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                              }`}>
                                KJ: {kj.hasLecturerSig ? '✓ Sah' : '✗ Tiada'}
                              </span>
                              <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                kj.hasEvaluatorSig ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                              }`}>
                                TP: {kj.hasEvaluatorSig ? '✓ Sah' : '✗ Tiada'}
                              </span>
                            </div>
                          ) : (
                            <span className="text-slate-300 font-bold">-</span>
                          )}
                        </td>

                        {/* Jadual Pemantauan TP */}
                        <td className="px-4 py-4 text-center">
                          {kj.schedule ? (
                            <div className="inline-flex items-center gap-2 p-1.5 bg-indigo-50 border border-indigo-100 rounded-xl text-left">
                              <div>
                                <div className="flex items-center gap-1 text-[11px] font-bold text-indigo-900">
                                  <CalendarDaysIcon className="h-3.5 w-3.5 text-indigo-600" />
                                  {formatDate(kj.schedule.date)}
                                </div>
                                <div className="text-[10px] text-indigo-700 font-medium">
                                  {kj.schedule.time} • {kj.schedule.location || 'Bilik Kuliah'}
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => onDeleteSchedule(kj.schedule!.id)}
                                className="p-1 bg-white hover:bg-rose-50 text-slate-400 hover:text-rose-600 border border-indigo-100 rounded-lg transition-colors shadow-2xs"
                                title="Padam Jadual Pemantauan KJ Ini"
                              >
                                <TrashIcon className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ) : (
                            <span className="text-xs text-slate-400">Tiada Jadual</span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="px-4 py-4 text-right">
                          <div className="flex items-center justify-end gap-1.5 flex-wrap">
                            {/* Primary Nilai TP Button */}
                            <button
                              type="button"
                              onClick={() => {
                                if (onStartEvaluation) {
                                  onStartEvaluation({
                                    lecturerName: kj.name,
                                    department: kj.department,
                                    course: kj.schedule?.course || '',
                                    code: kj.schedule?.code || '',
                                    date: new Date().toISOString().split('T')[0],
                                    evaluatorName: 'Dr. Muhaida Akmal binti Mohamad (TP)'
                                  });
                                }
                              }}
                              className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center gap-1 shadow-sm transition-all active:scale-95"
                              title={`Mulakan Penilaian TP untuk ${kj.name}`}
                            >
                              <SparklesIcon className="h-3.5 w-3.5" />
                              <span>{kj.isMonitored ? 'Nilai Lagi (TP)' : 'Nilai (TP)'}</span>
                            </button>

                            {/* If monitored: Kemaskini, PDF view, PDF download, Padam */}
                            {kj.latestRecord && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => onEditRecord(kj.latestRecord!)}
                                  className="p-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 rounded-xl transition-all shadow-sm"
                                  title="Kemaskini Rekod Penilaian Sesi Terkini"
                                >
                                  <PencilSquareIcon className="h-4 w-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => generatePDF(kj.latestRecord!, 'view')}
                                  className="p-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl transition-all shadow-sm"
                                  title="Lihat Paparan Borang PDF (LAM-PT-03-04)"
                                >
                                  <EyeIcon className="h-4 w-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => generatePDF(kj.latestRecord!, 'save')}
                                  className="p-1.5 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 rounded-xl transition-all shadow-sm"
                                  title="Muat Turun Dokumen PDF"
                                >
                                  <ArrowDownTrayIcon className="h-4 w-4" />
                                </button>
                                {kj.recordsCount > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => setSelectedLecturerHistory({ name: kj.name, records: kj.allRecords })}
                                    className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[10px] font-bold transition-all"
                                    title="Lihat semua rekod penilaian lampau"
                                  >
                                    Sejarah ({kj.recordsCount})
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(`Adakah anda pasti untuk memadam rekod penilaian bagi Ketua Jabatan ${kj.name}?`)) {
                                      onDeleteRecord(kj.latestRecord!.id);
                                    }
                                  }}
                                  className="p-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded-xl transition-all shadow-sm active:scale-95"
                                  title="Padam Rekod Penilaian Ini"
                                >
                                  <TrashIcon className="h-4 w-4" />
                                </button>
                              </>
                            )}

                            {/* If unmonitored: Quick button to Schedule */}
                            {!kj.latestRecord && (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingScheduleId(null);
                                  setSchedForm({
                                    lecturerName: kj.name,
                                    date: new Date().toISOString().split('T')[0],
                                    time: '08:00',
                                    course: '',
                                    code: '',
                                    location: 'Bilik Kuliah / Makmal'
                                  });
                                  setShowScheduleModal(true);
                                }}
                                className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 rounded-xl text-xs font-bold flex items-center gap-1 transition-all"
                                title={`Daftar Jadual Pemantauan TP untuk ${kj.name}`}
                              >
                                <CalendarDaysIcon className="h-3.5 w-3.5" />
                                <span>+ Jadual</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredKJList.length === 0 && (
                    <tr>
                      <td colSpan={10} className="px-8 py-16 text-center text-slate-400 italic">
                        Tiada Ketua Jabatan yang sepadan dengan carian atau tapisan anda.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Secondary Card: Upcoming TP Monitoring Schedule for Ketua Jabatan */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6">
              <div>
                <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <CalendarDaysIcon className="h-5 w-5 text-indigo-600" />
                  Jadual Pemantauan TP Khusus untuk Ketua Jabatan
                </h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-wider mt-0.5">
                  Sesi PdP Ketua Jabatan yang dijadualkan untuk pemantauan Timbalan Pengarah
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditingScheduleId(null);
                  setSchedForm({
                    lecturerName: '',
                    date: new Date().toISOString().split('T')[0],
                    time: '08:00',
                    course: '',
                    code: '',
                    location: 'Bilik Kuliah'
                  });
                  setShowScheduleModal(true);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
              >
                <CalendarDaysIcon className="h-4 w-4" />
                Tambah Jadual Pemantauan TP
              </button>
            </div>

            {(() => {
              const kjSchedules = schedules.filter(s => s.lecturerName.includes('(KJ)'));
              if (kjSchedules.length === 0) {
                return (
                  <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
                    <p className="text-sm font-bold text-slate-600">Belum ada sesi pemantauan yang dijadualkan khusus untuk Ketua Jabatan.</p>
                    <p className="text-xs text-slate-400 mt-1">Klik "+ Jadual Pemantauan TP" di atas untuk mendaftarkan sesi pemantauan bagi Ketua Jabatan.</p>
                  </div>
                );
              }
              return (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {kjSchedules.map(sched => {
                    const kjLecturer = allLecturers.find(l => l.name === sched.lecturerName);
                    return (
                      <div key={sched.id} className="p-5 bg-gradient-to-br from-indigo-50/50 to-purple-50/40 border border-indigo-100 rounded-2xl flex flex-col justify-between space-y-4 hover:border-indigo-300 transition-all">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-md text-[10px] font-black uppercase">
                              {formatDate(sched.date)} • {sched.time}
                            </span>
                            <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded-md text-[9px] font-black uppercase">
                              KJ
                            </span>
                          </div>
                          <div>
                            <h4 className="text-sm font-black text-slate-900">{sched.lecturerName}</h4>
                            <p className="text-xs text-slate-500 font-medium">{sched.department || kjLecturer?.department}</p>
                          </div>
                          <div className="pt-2 border-t border-indigo-100/60 text-xs text-slate-700 space-y-1">
                            <p className="font-bold">{sched.code} - {sched.course}</p>
                            <p className="text-slate-500 text-[11px] flex items-center gap-1">
                              <MapPinIcon className="h-3 w-3 text-slate-400" />
                              {sched.location || 'Lokasi Belum Ditetapkan'}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pt-2 border-t border-indigo-100/60">
                          <button
                            type="button"
                            onClick={() => {
                              if (onStartEvaluation) {
                                onStartEvaluation({
                                  lecturerName: sched.lecturerName,
                                  department: sched.department || kjLecturer?.department || '',
                                  course: sched.course,
                                  code: sched.code,
                                  date: sched.date,
                                  evaluatorName: 'Dr. Muhaida Akmal binti Mohamad (TP)'
                                });
                              }
                            }}
                            className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 shadow-sm transition-all"
                          >
                            <SparklesIcon className="h-3.5 w-3.5" />
                            Nilai Sekarang
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingScheduleId(sched.id);
                              setSchedForm({
                                lecturerName: sched.lecturerName,
                                date: sched.date,
                                time: sched.time,
                                course: sched.course,
                                code: sched.code,
                                location: sched.location || ''
                              });
                              setShowScheduleModal(true);
                            }}
                            className="p-2 bg-white hover:bg-indigo-50 border border-slate-200 text-slate-600 rounded-xl transition-all"
                            title="Ubahsuai Jadual"
                          >
                            <PencilSquareIcon className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteSchedule(sched.id)}
                            className="p-2 bg-white hover:bg-rose-50 border border-slate-200 text-rose-600 rounded-xl transition-all shadow-xs active:scale-95"
                            title="Padam Jadual Pemantauan Ketua Jabatan Ini"
                          >
                            <TrashIcon className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        </div>
        )
      )}

      {/* Department Details Modal */}
      {selectedDeptDetails && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[80vh] overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div>
                <h3 className="text-xl font-black text-slate-800">{selectedDeptDetails}</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Senarai Keseluruhan Pensyarah</p>
              </div>
              <button onClick={() => setSelectedDeptDetails(null)} className="p-2 hover:bg-white rounded-full transition-colors">
                <XMarkIcon className="h-6 w-6 text-slate-400" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest flex items-center gap-1">
                    <CheckBadgeIcon className="h-3 w-3" /> Sudah Dipantau ({departmentMonitoringStats.find(d => d.name === selectedDeptDetails)?.monitored})
                  </p>
                  <div className="space-y-1.5">
                    {allLecturers
                      .filter(l => l.department === selectedDeptDetails && records.some(r => r.lecturerName.toLowerCase() === l.name.toLowerCase()))
                      .map(l => {
                        const isNew = !LECTURERS.some(staticL => staticL.name.toLowerCase() === l.name.toLowerCase());
                        return (
                          <div key={l.name} className={`p-3 border rounded-xl flex items-center justify-between ${isNew ? 'bg-indigo-50/50 border-indigo-100' : 'bg-emerald-50/50 border-emerald-100'}`}>
                            <div className="flex items-center gap-2">
                              <span className={`text-xs font-bold ${isNew ? 'text-indigo-900' : 'text-emerald-900'}`}>{l.name}</span>
                              {isNew && <SparklesIcon className="h-3 w-3 text-indigo-500" />}
                            </div>
                            <div className="flex items-center gap-1.5">
                              <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase ${isNew ? 'bg-indigo-100 text-indigo-700' : 'bg-emerald-100 text-emerald-700'}`}>
                                {isNew ? 'Baru' : (records.filter(r => r.lecturerName.toLowerCase() === l.name.toLowerCase()).length > 1 ? `${records.filter(r => r.lecturerName.toLowerCase() === l.name.toLowerCase()).length} Rekod` : 'Selesai')}
                              </span>
                              {records.find(r => r.lecturerName.toLowerCase() === l.name.toLowerCase()) && (
                                <button 
                                  onClick={() => {
                                    const rec = records.find(r => r.lecturerName.toLowerCase() === l.name.toLowerCase());
                                    if (rec) {
                                      setSelectedDeptDetails(null);
                                      onEditRecord(rec);
                                    }
                                  }}
                                  className="px-2 py-0.5 bg-white hover:bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-[9px] font-bold flex items-center gap-1 shadow-sm transition-all"
                                  title="Kemaskini Rekod Pemantauan"
                                >
                                  <PencilSquareIcon className="h-3 w-3" /> Kemaskini
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    {allLecturers.filter(l => l.department === selectedDeptDetails && records.some(r => r.lecturerName.toLowerCase() === l.name.toLowerCase())).length === 0 && (
                      <p className="text-xs text-slate-400 italic">Tiada rekod.</p>
                    )}
                  </div>
                </div>
                <div className="space-y-3">
                  <p className="text-[10px] font-black text-rose-600 uppercase tracking-widest flex items-center gap-1">
                    <ClockIcon className="h-3 w-3" /> Belum Dipantau ({departmentMonitoringStats.find(d => d.name === selectedDeptDetails)?.unmonitoredNames.length})
                  </p>
                  <div className="space-y-1.5">
                    {allLecturers
                      .filter(l => l.department === selectedDeptDetails && !records.some(r => r.lecturerName.toLowerCase() === l.name.toLowerCase()))
                      .map(l => (
                        <div key={l.name} className="p-3 bg-rose-50/50 border border-rose-100 rounded-xl flex items-center justify-between">
                          <span className="text-xs font-bold text-rose-900">{l.name}</span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[8px] font-black bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded uppercase">Belum</span>
                            {/* Action buttons removed */}
                          </div>
                        </div>
                      ))}
                    {allLecturers.filter(l => l.department === selectedDeptDetails && !records.some(r => r.lecturerName.toLowerCase() === l.name.toLowerCase())).length === 0 && (
                      <p className="text-xs text-emerald-600 font-bold">Semua telah dipantau! ✨</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button onClick={() => setSelectedDeptDetails(null)} className="px-6 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-100 transition-all">
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {showAIModal && !isRestricted && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="bg-indigo-600 px-6 py-4 flex justify-between items-center text-white font-bold">
              <span className="flex items-center gap-2"><SparklesIcon className="h-5 w-5" /> Rumusan AI Gemini</span>
              <button onClick={() => setShowAIModal(false)}><XMarkIcon className="h-6 w-6" /></button>
            </div>
            <div className="p-8">
              <p className="text-lg font-black text-slate-800 mb-4">{activeLecturer}</p>
              {isSummarizing ? (
                <div className="py-12 flex flex-col items-center"><ArrowPathIcon className="h-10 w-10 text-indigo-600 animate-spin" /><p className="text-sm font-medium text-slate-500 mt-4">Menganalisis...</p></div>
              ) : (
                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 text-sm whitespace-pre-wrap max-h-80 overflow-y-auto">{aiSummary}</div>
              )}
              <div className="mt-8 flex justify-end"><button onClick={() => setShowAIModal(false)} className="px-8 py-3 bg-slate-900 text-white rounded-xl font-bold">Tutup</button></div>
            </div>
          </div>
        </div>
      )}

      {showScheduleModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white font-bold">
              <span><CalendarDaysIcon className="h-5 w-5 inline mr-2" /> {editingScheduleId ? 'Ubahsuai' : 'Daftar'} Jadual</span>
              <button onClick={() => setShowScheduleModal(false)}><XMarkIcon className="h-6 w-6" /></button>
            </div>
            <form onSubmit={handleScheduleSubmit} className="p-8 space-y-4">
              <select required value={schedForm.lecturerName} onChange={e => setSchedForm({...schedForm, lecturerName: e.target.value})} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm shadow-inner">
                <option value="" disabled>
                  {isDeptView ? `Pilih Pensyarah (${currentDept})` : 'Pilih Pensyarah (Semua Jabatan)'}
                </option>
                {(isDeptView ? currentDeptLecturers : allLecturers)
                  .sort((a,b) => a.name.localeCompare(b.name))
                  .map(l => (
                    <option key={l.name} value={l.name}>
                      {l.name} {isDeptView ? '' : `(${l.department})`}
                    </option>
                  ))
                }
              </select>
              <div className="grid grid-cols-2 gap-4">
                <input required type="date" value={schedForm.date} onChange={e => setSchedForm({...schedForm, date: e.target.value})} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                <input required type="time" value={schedForm.time} onChange={e => setSchedForm({...schedForm, time: e.target.value})} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
              </div>
              <input required type="text" value={schedForm.course} onChange={e => setSchedForm({...schedForm, course: e.target.value})} placeholder="Nama Kursus" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
              <div className="grid grid-cols-2 gap-4">
                <input required type="text" value={schedForm.code} onChange={e => setSchedForm({...schedForm, code: e.target.value})} placeholder="Kod" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
                <input required type="text" value={schedForm.location} onChange={e => setSchedForm({...schedForm, location: e.target.value})} placeholder="Lokasi (cth: Bilik Kuliah / Google Meet)" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" />
              </div>
              <div className="pt-4 flex justify-between items-center gap-3">
                {editingScheduleId ? (
                  <button
                    type="button"
                    onClick={() => {
                      const idToDelete = editingScheduleId;
                      setShowScheduleModal(false);
                      onDeleteSchedule(idToDelete);
                    }}
                    className="px-4 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-1 transition-all active:scale-95"
                    title="Padam jadual pemantauan ini"
                  >
                    <TrashIcon className="h-4 w-4" /> Padam Jadual
                  </button>
                ) : <div />}
                <div className="flex gap-2">
                  <button type="button" onClick={() => setShowScheduleModal(false)} className="px-5 py-2 text-sm font-bold text-slate-500 hover:text-slate-700">Batal</button>
                  <button type="submit" className="px-6 py-2 bg-indigo-600 text-white font-black rounded-xl text-sm shadow-lg shadow-indigo-100 transition-all hover:bg-indigo-700 active:scale-95">Simpan Jadual</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {showLecturerModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <AcademicCapIcon className="h-6 w-6 text-rose-600" />
                {editingLecturer ? 'Ubahsuai Pensyarah' : 'Tambah Pensyarah Baru'}
              </h2>
              <button onClick={() => setShowLecturerModal(false)} className="p-2 hover:bg-white rounded-full transition-colors">
                <XMarkIcon className="h-6 w-6 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleLecturerSubmit} className="p-8 space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Nama Penuh</label>
                  <input 
                    required
                    type="text" 
                    value={lecturerFormData.name}
                    onChange={e => setLecturerFormData({...lecturerFormData, name: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all"
                    placeholder="Contoh: Dr. Ahmad Bin Ali"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Jabatan / Unit</label>
                  {!isOtherDept ? (
                    <select 
                      required
                      disabled={!isAdminView || isDeptView}
                      value={isDeptView ? currentDept : lecturerFormData.department}
                      onChange={e => {
                        if (e.target.value === 'OTHER') {
                          setIsOtherDept(true);
                          setLecturerFormData({...lecturerFormData, department: ''});
                        } else {
                          setLecturerFormData({...lecturerFormData, department: e.target.value});
                        }
                      }}
                      className={`w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all appearance-none ${(!isAdminView || isDeptView) ? 'cursor-not-allowed opacity-70' : ''}`}
                    >
                      <option value="" disabled>Pilih Jabatan</option>
                      {DEPARTMENTS.map(dept => <option key={dept} value={dept}>{dept}</option>)}
                      <option value="OTHER">LAIN-LAIN (Sila Nyatakan)</option>
                    </select>
                  ) : (
                    <div className="flex gap-2">
                      <input 
                        required
                        type="text" 
                        value={lecturerFormData.department}
                        onChange={e => setLecturerFormData({...lecturerFormData, department: e.target.value})}
                        className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all"
                        placeholder="Masukkan Nama Jabatan"
                        autoFocus
                      />
                      <button 
                        type="button"
                        onClick={() => {
                          setIsOtherDept(false);
                          setLecturerFormData({...lecturerFormData, department: ''});
                        }}
                        className="px-3 py-2 text-xs font-bold text-slate-400 hover:text-slate-600"
                      >
                        Batal
                      </button>
                    </div>
                  )}
                </div>
                <div>
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input 
                      type="checkbox" 
                      checked={lecturerFormData.isKJ}
                      onChange={e => setLecturerFormData({...lecturerFormData, isKJ: e.target.checked})}
                      className="w-5 h-5 rounded border-slate-300 text-rose-600 focus:ring-rose-500 transition-all cursor-pointer"
                    />
                    <span className="text-sm font-bold text-slate-700 group-hover:text-rose-600 transition-colors">
                      Ketua Jabatan (KJ)
                    </span>
                  </label>
                  <p className="mt-1 text-xs text-slate-400 ml-7">
                    Tandakan jika pensyarah ini adalah Ketua Jabatan.
                  </p>
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button" 
                  onClick={() => setShowLecturerModal(false)}
                  className="flex-1 px-6 py-3 text-sm font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition-all"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-6 py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
                >
                  {editingLecturer ? 'Simpan Perubahan' : 'Tambah Pensyarah'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selectedLecturerHistory && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[80vh] overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div>
                <h3 className="text-xl font-black text-slate-800">{selectedLecturerHistory.name}</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Sejarah Pemantauan ({selectedLecturerHistory.records.length} Rekod)</p>
              </div>
              <button onClick={() => setSelectedLecturerHistory(null)} className="p-2 hover:bg-white rounded-full transition-colors">
                <XMarkIcon className="h-6 w-6 text-slate-400" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">
              {selectedLecturerHistory.records.map((record, idx) => {
                const allScores = Object.values(record.scores);
                const avg = allScores.length > 0 ? (allScores.reduce((a, b) => a + b, 0) / allScores.length).toFixed(2) : '0.00';
                return (
                  <div key={record.id} className="p-5 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-indigo-200 transition-all">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black text-slate-800">Sesi #{selectedLecturerHistory.records.length - idx}</span>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{formatDate(record.date)}</span>
                      </div>
                      <p className="text-xs text-slate-600 font-bold">{record.code} - {record.course}</p>
                      <p className="text-[10px] text-slate-400">Pemantau: {record.evaluatorName}</p>
                    </div>
                    <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
                      <div className="text-right">
                        <p className="text-lg font-black text-indigo-600">{avg}</p>
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Purata Skor</p>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => { setSelectedLecturerHistory(null); onEditRecord(record); }} 
                          className="p-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 rounded-xl transition-all shadow-sm" 
                          title="Kemaskini Rekod Pemantauan Sesi Ini"
                        >
                          <PencilSquareIcon className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => generatePDF(record, 'view')} 
                          className="p-2 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition-colors"
                          title="Lihat PDF"
                        >
                          <EyeIcon className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => generatePDF(record, 'save')} 
                          className="p-2 bg-indigo-50 border border-indigo-100 text-indigo-600 rounded-xl hover:bg-indigo-100 transition-colors"
                          title="Muat Turun PDF"
                        >
                          <ArrowDownTrayIcon className="h-4 w-4" />
                        </button>
                        {(isAdminView || canEdit) && (
                          <button 
                            onClick={() => { setSelectedLecturerHistory(null); onDeleteRecord(record.id); }} 
                            className="p-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded-xl transition-all shadow-sm active:scale-95" 
                            title="Padam Rekod Pemantauan Sesi Ini"
                          >
                            <TrashIcon className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button onClick={() => setSelectedLecturerHistory(null)} className="px-6 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-100 transition-all">
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Pengesahan Akses Timbalan Pengarah (TP) */}
      {showTPAuthModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="bg-gradient-to-r from-purple-900 to-indigo-900 px-6 py-5 flex justify-between items-center text-white">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/10 rounded-xl">
                  <ShieldCheckIcon className="h-6 w-6 text-purple-300" />
                </div>
                <div>
                  <h3 className="text-base font-black">Akses Timbalan Pengarah (TP)</h3>
                  <p className="text-[10px] text-purple-200 uppercase tracking-widest font-bold">Portal Pemantauan Ketua Jabatan</p>
                </div>
              </div>
              <button 
                type="button" 
                onClick={() => { setShowTPAuthModal(false); setTpAuthError(''); }}
                className="p-1.5 hover:bg-white/10 rounded-full transition-colors"
              >
                <XMarkIcon className="h-5 w-5 text-white/80" />
              </button>
            </div>
            <form onSubmit={handleTPAuthSubmit} className="p-6 sm:p-8 space-y-5">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-2">
                  <LockClosedIcon className="h-6 w-6" />
                </div>
                <p className="text-sm font-bold text-slate-800">
                  Hanya TP Sahaja Boleh Akses
                </p>
                <p className="text-xs text-slate-500">
                  Sila masukkan kata laluan Timbalan Pengarah (<strong className="text-purple-700">tp</strong>) untuk membuka paparan pemantauan khas ini.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wider">
                  Password TP:
                </label>
                <div className="relative">
                  <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                    <KeyIcon className="h-5 w-5" />
                  </div>
                  <input
                    type="password"
                    required
                    autoFocus
                    value={tpPasswordInput}
                    onChange={e => setTpPasswordInput(e.target.value)}
                    placeholder="Masukkan password tp"
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-purple-500 outline-none transition-all"
                  />
                </div>
                {tpAuthError && (
                  <p className="mt-2 text-xs font-bold text-rose-600 flex items-center gap-1">
                    <ExclamationCircleIcon className="h-4 w-4 shrink-0" />
                    {tpAuthError}
                  </p>
                )}
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowTPAuthModal(false); setTpAuthError(''); }}
                  className="flex-1 py-3 text-sm font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-sm font-black shadow-lg shadow-purple-200 transition-all active:scale-95"
                >
                  Log In ke Paparan TP
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <UserGuideModal 
        isOpen={showGuideModal}
        onClose={() => setShowGuideModal(false)}
      />

      {showSyncModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300" onClick={() => setShowSyncModal(false)} />
          <div className="relative bg-white rounded-3xl border border-slate-200 max-w-lg w-full overflow-hidden flex flex-col animate-in zoom-in-95 duration-300 shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-indigo-600 rounded-2xl text-white shadow-md shadow-indigo-100">
                  <ArrowPathIcon className={`h-6 w-6 ${isSyncing ? 'animate-spin' : ''}`} />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-800 tracking-tight">Penyelarasan Multi-Peranti</h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Laptop, Android, Mac & Windows</p>
                </div>
              </div>
              <button 
                onClick={() => setShowSyncModal(false)} 
                className="p-2 hover:bg-slate-200 rounded-full transition-colors text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <XMarkIcon className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              <div className="p-4 bg-indigo-50/70 border border-indigo-100 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-indigo-900 uppercase tracking-wide">Status Sambungan Pelayan</span>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                    syncError ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${syncError ? 'bg-rose-500' : 'bg-emerald-500 animate-pulse'}`} />
                    {syncError ? 'Sambungan Terhad' : 'Tersambung & Aktif'}
                  </span>
                </div>
                <p className="text-xs text-indigo-700/90 leading-relaxed">
                  Sistem menyelaraskan rekod, jadual, dan tandatangan secara automatik setiap 4 saat dan menyokong penjimatan setempat secara selamat sekiranya di luar talian.
                </p>
                {lastSync && (
                  <p className="text-[10px] text-indigo-600 font-semibold pt-1 border-t border-indigo-100">
                    Masa Terakhir Diselaraskan: {lastSync.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </p>
                )}
              </div>

              <div>
                <p className="text-[11px] font-black text-slate-500 uppercase tracking-wider mb-2.5">Sokongan Merentasi Peranti</p>
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-start gap-2.5">
                    <ComputerDesktopIcon className="h-5 w-5 text-indigo-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-slate-800">Laptop & Komputer</p>
                      <p className="text-[10px] text-slate-500">Windows, Mac & Linux</p>
                      <span className="text-[9px] font-black text-emerald-600 mt-0.5 inline-block">✓ Selaras Automatik</span>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-start gap-2.5">
                    <DevicePhoneMobileIcon className="h-5 w-5 text-indigo-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-slate-800">Telefon Pintar</p>
                      <p className="text-[10px] text-slate-500">Android & iPhone (iOS)</p>
                      <span className="text-[9px] font-black text-emerald-600 mt-0.5 inline-block">✓ Selaras Automatik</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-2xl">
                <div className="grid grid-cols-3 gap-2 text-center divide-x divide-slate-200">
                  <div>
                    <p className="text-base font-black text-slate-800">{records.length}</p>
                    <p className="text-[9px] font-bold text-slate-500 uppercase">Rekod Penilaian</p>
                  </div>
                  <div>
                    <p className="text-base font-black text-slate-800">{schedules.length}</p>
                    <p className="text-[9px] font-bold text-slate-500 uppercase">Jadual Sesi</p>
                  </div>
                  <div>
                    <p className="text-base font-black text-slate-800">{allLecturers.length}</p>
                    <p className="text-[9px] font-bold text-slate-500 uppercase">Pensyarah</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => setShowSyncModal(false)}
                  className="flex-1 py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all cursor-pointer"
                >
                  Tutup
                </button>
                {onSync && (
                  <button
                    type="button"
                    onClick={() => {
                      onSync();
                      setShowSyncModal(false);
                    }}
                    disabled={isSyncing}
                    className="flex-1 py-2.5 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-200 transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                  >
                    <ArrowPathIcon className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>{isSyncing ? 'Menyelaraskan...' : 'Segerak Sekarang'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};